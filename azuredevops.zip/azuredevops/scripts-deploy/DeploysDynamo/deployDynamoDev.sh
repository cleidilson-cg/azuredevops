#!/bin/bash
awsProf=$1
echo ARQUIVO: ${arquivo}
echo $1:$awsProf
ttl=`cat ${arquivo}.tags.output.json | grep -A 1 "TimeToLive" | grep "Value" | cut -d'"' -f4`
release=`cat table.${arquivo}.json | grep "release" | cut -d'"' -f4`

userAwsId=`aws sts get-caller-identity --profile $awsProf | grep "Account" | cut -d'"' -f4`

sed -i "s/#userID/$userAwsId/"g ${arquivo}.tags.output.json

if [[ `echo $ttl |grep -i "true"` ]]; then
	aws cloudformation deploy --template-file ${arquivo}.output.json --stack-name DYNAMO0${arquivo} --profile $awsProf
	aws dynamodb tag-resource --cli-input-json fileb://${arquivo}.tags.output.json --profile $awsProf

	echo "############ Configurando TimeToLive #################"
	aws dynamodb update-time-to-live --table-name ${arquivo} --time-to-live-specification Enabled=true,AttributeName=_ttl --profile $awsProf || true	
else 
	aws cloudformation deploy --template-file ${arquivo}.output.json --stack-name DYNAMO0${arquivo} --profile $awsProf
fi