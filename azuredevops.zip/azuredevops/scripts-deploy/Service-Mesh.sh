#namespaces=$(kubectl get namespaces | awk '{print $1}' | grep -E '(-qa|-dev|-pprd)$')

namespaces=$(kubectl get namespaces | awk '{print $1}' | grep -E '(devops-tfsagent)$')
for ns in $namespaces 
  do
    echo namespace $ns
    oc project $ns
    oc get smmr default -n istio-system-dev -o json | jq '.spec.members |= . + ["'$ns'"]' | oc apply -f -
      deploy=$(kubectl get deployment -n $ns --no-headers -o custom-columns=":metadata.name")
      echo =====================================================
        for d in $deploy 
          do
            echo "deployment $d"
            oc patch deployment/$d -p '{"spec":{"template":{"metadata":{"annotations":{"sidecar.istio.io/inject":"true"}}}}}' -n $ns 
          done
      host=$(oc get route -o json | jq -r '.items[].spec.host')
        for h in $hosts
          do
            route_name=$(oc get route -o json | jq -r '.items[].metadata.name')
            cat <<EOF >./istio-gw.yaml
            kind: Gateway
            apiVersion: networking.istio.io/v1alpha3
            metadata:
            name: $route_name-gw
            namespace: $ns
            spec:
            servers:
                - hosts:
                    - $host
                port:
                    name: http
                    number: 80
                    protocol: HTTP
            selector:
                istio: ingressgateway
            EOF

            cat <<EOF >./istio-vs.yaml
            kind: VirtualService
            apiVersion: networking.istio.io/v1alpha3
            metadata:
            name: $route_name-vs
            namespace: $ns
            spec:
            hosts:
                - $host
            gateways:
                - $name-gw
            http:
                - match:
                    - uri:
                        prefix: /
                route:
                    - destination:
                        host: $name
                        port:
                        number: 8080
            EOF
            kubectl apply -f istio-gw.yaml
            kubectl apply -f istio-vs.yaml
            #oc delete route $route_name
          done
  done




