#!/bin/bash
echo "############################################################"
echo "############### Deploy AWS ${arquivoTratado} ###############"
echo "############################################################"

awsRole="arn:aws:iam::${userAwsId}:role/${role}"

operation_multiple=$(echo ${operacao} | sed 's/ //g' | awk '{gsub(/,/,"\n",$1); print $1}')
for operation in ${operation_multiple}; do
    sleep 60
    existe=$(aws lambda get-function --function-name ${lambda} --profile ${awsProf} || true)
    lambdaUpdate=$(echo "${existe}" | grep "FunctionName" | cut -d'"' -f4)
    echo "Lambda function ${lambdaUpdate}"

    if [[ $(echo ${regiao} | grep -i "us-east-1") ]]; then
        existe=$(aws lambda get-function --function-name ${lambda} --profile ${awsProf} --region ${regiao} || true)
        lambdaUpdate=$(echo "${existe}" | grep "FunctionName" | cut -d'"' -f4)
        if [[ $operation == "codigo" ]];then
            if [[ -z ${lambdaUpdate} ]]; then
                echo "${lambda} NAO existe. CRIANDO..."
                aws lambda create-function --role ${awsRole} --cli-input-json fileb://scriptsAws/config.json --zip-file fileb://${arquivoTratado}.zip --profile ${awsProf} --region ${regiao}
            else
                echo "${lambda} existe fazendo apenas UPDATE..."
                aws lambda update-function-code --function-name ${lambda} --zip-file fileb://${arquivoTratado}.zip --profile ${awsProf} --region ${regiao}
            fi
                
        elif [[ $operation ==  "configuracao" ]];then
            if [[ -z ${lambdaUpdate} ]]; then
                echo "${lambda} NAO existe. Não é necessário realizar configuração..."
            else
                aws lambda update-function-configuration --cli-input-json fileb://scriptsAws/config.json --vpc-config SubnetIds=[],SecurityGroupIds=[] --profile ${awsProf} --region ${regiao}
            fi
        
        elif [[ $operation ==  "trigger" ]];then
            aws s3api put-bucket-notification-configuration --cli-input-json fileb://scriptsAws/s3Trigger.json --profile ${awsProf} --region ${regiao}
        
        elif [[ $operation ==  "concurrency" ]];then
            aws lambda put-function-concurrency --cli-input-json fileb://scriptsAws/reservedConcurrentExecutions.json --profile ${awsProf} --region ${regiao}
        
        elif [[ $operation ==  "tag" ]];then
            aws lambda tag-resource --cli-input-json fileb://scriptsAws/tags.json --profile ${awsProf} --region ${regiao}
        
        elif [[ $operation ==  "sqs" ]];then
            aws lambda create-event-source-mapping --cli-input-json fileb://scriptsAws/sqsTrigger.json --profile ${awsProf} --region ${regiao}
        fi

    elif [[ $(echo ${vpc} | grep -i "sim") ]]; then
        if [[ $operation == "codigo" ]];then
            if [[ -z ${lambdaUpdate} ]]; then
                echo "${lambda} NAO existe. CRIANDO..."
                aws lambda create-function --role ${awsRole} --cli-input-json fileb://scriptsAws/config.json --zip-file fileb://${arquivoTratado}.zip --vpc-config SubnetIds=${sn},SecurityGroupIds=${sg} --profile ${awsProf}
            else
                echo "${lambda} existe. Fazendo apenas UPDATE..."
                aws lambda update-function-code --function-name ${lambda} --zip-file fileb://${arquivoTratado}.zip --profile ${awsProf}
            fi
                
        elif [[ $operation ==  "configuracao" ]];then
            if [[ -z ${lambdaUpdate} ]]; then
                echo "${lambda} NAO existe. Não é necessário realizar configuração..."
            else
                aws lambda update-function-configuration --cli-input-json fileb://scriptsAws/config.json --vpc-config SubnetIds=${sn},SecurityGroupIds=${sg} --profile ${awsProf}
            fi
        
        elif [[ $operation ==  "trigger" ]];then
            aws s3api put-bucket-notification-configuration --cli-input-json fileb://scriptsAws/s3Trigger.json --vpc-config SubnetIds=${sn},SecurityGroupIds=${sg} --profile ${awsProf} ## nao tem em prd sn sg
        
        elif [[ $operation ==  "concurrency" ]];then
            aws lambda put-function-concurrency --cli-input-json fileb://scriptsAws/reservedConcurrentExecutions.json --profile ${awsProf}
        
        elif [[ $operation ==  "tag" ]];then
            aws lambda tag-resource --cli-input-json fileb://scriptsAws/tags.json --profile ${awsProf}
        
        elif [[ $operation ==  "sqs" ]];then
            aws lambda create-event-source-mapping --cli-input-json fileb://scriptsAws/sqsTrigger.json --profile ${awsProf}
        fi

    else
        if [[ $operation == "codigo" ]];then
            if [[ -z ${lambdaUpdate} ]]; then
                echo "${lambda} NAO existe. CRIANDO..."
                aws lambda create-function --role ${awsRole} --cli-input-json fileb://scriptsAws/config.json --zip-file fileb://${arquivoTratado}.zip --profile ${awsProf}
            else
                echo "${lambda} existe. Fazendo apenas UPDATE..."
                aws lambda update-function-code --function-name ${lambda} --zip-file fileb://${arquivoTratado}.zip --profile ${awsProf}
            fi
                
        elif [[ $operation ==  "configuracao" ]];then
            if [[ -z ${lambdaUpdate} ]]; then
                echo "${lambda} NAO existe. Não é necessário realizar configuração..."
            else
                aws lambda update-function-configuration --cli-input-json fileb://scriptsAws/config.json --vpc-config SubnetIds=[],SecurityGroupIds=[] --profile ${awsProf}
            fi
        
        elif [[ $operation ==  "trigger" ]];then
            aws s3api put-bucket-notification-configuration --cli-input-json fileb://scriptsAws/s3Trigger.json --profile ${awsProf}
        
        elif [[ $operation ==  "concurrency" ]];then
            aws lambda put-function-concurrency --cli-input-json fileb://scriptsAws/reservedConcurrentExecutions.json --profile ${awsProf}
        
        elif [[ $operation ==  "tag" ]];then
            aws lambda tag-resource --cli-input-json fileb://scriptsAws/tags.json --profile ${awsProf}
        
        elif [[ $operation ==  "sqs" ]];then
            aws lambda create-event-source-mapping --cli-input-json fileb://scriptsAws/sqsTrigger.json --profile ${awsProf}
        fi
    fi

    status=$?
    if [ $status != 0 ];then
        echo "############################################"
        echo "## Erro ao executar a operação $operation ##"
        echo "############################################"
        exit 3
    fi
done

if [[ $(echo ${regiao} | grep -i "us-east-1") ]]; then
    aws lambda tag-resource --cli-input-json fileb://scriptsAws/tags.json --profile ${awsProf} --region ${regiao}
    aws lambda tag-resource --resource arn:aws:lambda:${regiao}:${userAwsId}:function:${lambda} --tags ReleaseAnterior=${release_antiga} --profile ${awsProf} --region ${regiao}
else
    aws lambda tag-resource --cli-input-json fileb://scriptsAws/tags.json --profile ${awsProf}
    aws lambda tag-resource --resource arn:aws:lambda:sa-east-1:${userAwsId}:function:${lambda} --tags ReleaseAnterior=${release_antiga} --profile ${awsProf}
fi