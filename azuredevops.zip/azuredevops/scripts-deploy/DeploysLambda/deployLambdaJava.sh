#!/bin/bash
for conta in $(cat $localpath/$repo/lambda-profile-env); do

    pathConfig="$localpath/scripts-deploy/DeploysLambda/config/$branch/$conta"
    profile=$(cat $pathConfig | grep awsProf | cut -b 9- | tr -d \")
    bucket=$(aws s3api list-buckets --profile $profile | jq -r '.Buckets[].Name' | grep "^teste-*")
    role=$(cat $pathConfig | grep role | cut -b 6- | tr -d \")
    userAwsId=$(aws sts get-caller-identity --profile $profile | grep "Account" | cut -d'"' -f4)
    lambdaUpdate=$(aws lambda get-function --function-name $function --profile $profile | grep $repo | cut -d'"' -f4)
    awsRole="arn:aws:iam::$userAwsId:role/$role"

    echo "REALIZANDO DEPLOY NA CONTA $conta"
    echo "Lambda function $lambdaUpdate"

    if [[ -z $lambdaUpdate ]]; then
        echo "$function NAO existe. CRIANDO..."
        aws lambda create-function --role $awsRole --runtime java11 --handler br.com.semparar.pci.pciproxytokenizerservice.aws.StreamLambdaHandler::handleRequest --function-name lamba-java --code S3Bucket=$bucket,S3Key=$package --profile $profile
    else
        echo "$function existe, fazendo apenas UPDATE..."
        aws lambda update-function-code --function-name lamba-java --s3-bucket $bucket --s3-key  --profile DEV
    fi
done
