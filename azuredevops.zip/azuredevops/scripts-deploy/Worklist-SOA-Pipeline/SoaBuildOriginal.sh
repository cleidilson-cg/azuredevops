#!/bin/bash

## ex. ./geraJarBpel.sh StpSoaApplication_TU BS_ControlaViagem unitario

#set +e 

if [ $# -ne 5 ]
then
  echo "Uso: "
  echo "  ${0} <path_do_Branch> <Objeto_a_ser_gerado> <Ambiente> <Diretorio_onde_sera_copiado_o_artefato_gerado> <Numero Mantis>"
  echo "Exemplo:"
  echo "  ${0} geraJarBpelMavenAmbstpTag.sh StpSoaApplication_TU BS_ConsultaEmbarcador tu /home/stp/deploy/soaSuite/23_04_TU_M14302"
  exit 1
fi

#### Variaveis de entrada
root=`pwd`
usuario="isaelin.ewave"
senha="isaelin.ewave"
pathBranch="/app/jenkins/workspace/WORKLIST_UAT_GIT/UAT"
pathBranchSOA="$pathBranch/worklist"
pathAbsolutoMerge="/app/jenkins/workspace/WORKLIST_UAT_GIT/TS"
pathAbsolutoMergeSOA="$pathAbsolutoMerge/worklist"
application=$1
svnDir=$pathBranchSOA/$application
compositeName=$2
env=$3
dir_pacote=$4
mantis=$5
#version='1.0'
#commit_comment=`echo $dir_pacote | rev | cut -d/ -f 1 | rev`
#formatDateTag=`date +"%Y%m%d%H%M%S"`
#tagName=$mantis"_"$formatDateTag

#cd $svnDir
#urlSvn=`svn info | grep URL`
#urlSvnBranch=`echo $urlSvn | cut -d " " -f2`
#urlSvnTag=`echo $urlSvnBranch | cut -d "b" -f1`
#urlSvnTagTratada=$urlSvnTag"tags/"$tagName
#cd $root

# Cria os diretórios de TU e TS
mkdir -p $pathBranch
mkdir -p $pathAbsolutoMerge

# Verifica se os diretóios existem, caso existam, serão apagado e clonando novamente
    echo "Clonando uat..."
    echo " "
    if [ -d "$pathBranch" ]; then
        cd $pathBranch
        rm -rf worklist
        git clone -b uat ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/worklist --depth=1
    fi
    echo ""
    echo "Clonando tu..."
    echo ""
    if [ -d "$pathAbsolutoMerge" ]; then
        cd $pathAbsolutoMerge
        rm -rf worklist
        git clone -b tu ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/worklist --depth=1         
    fi
    echo "\033[0m"


# .adf/META-INF/adf-config.xml original, pois a equipe de desenvolvimento sobe o arquivo configurado da máquina local.

#cp -rf /var/lib/jenkins/workspace/adf/META-INF/adf-config_pincado.xml $svnDir/.adf/META-INF/adf-config.xml
cp -rf /app/jenkins/workspace/adf/META-INF/adf-config.xml /app/jenkins/workspace/WORKLIST_UAT_GIT/UAT/worklist/work-flow/N2N3/.adf/META-INF
sed -i 's/#job/worklist_common/g' /app/jenkins/workspace/WORKLIST_UAT_GIT/UAT/worklist/work-flow/N2N3/.adf/META-INF/adf-config.xml
sed -i 's&/#ambiente&&g' /app/jenkins/workspace/WORKLIST_UAT_GIT/UAT/worklist/work-flow/N2N3/.adf/META-INF/adf-config.xml

mkdir $dir_pacote

# tratando a variável $compositeName para seja possível gerar mais de um objeto ao mesmo tempo
compositeName_multiple=`echo ${compositeName} | awk '{gsub(/,/,"\n",$1); print $1}'`
echo "Objeto(s) que sera(ao) gerado(s): $compositeName_multiple "
          
#Configurar essas duas variaveis com o caminho do ant e jdev instalados na conta atual
antDir='/app/soa12c/soa/bin'
jdevDir='/app/soa12c/soa/bin'

#Atualizado o project.properties a proxima versao do BS
versao=`cat $svnDir/project.properties | grep version | cut -f2 -d'='`
versao_tratada=`echo $versao | cut -f1 -d'.'`
next_version=$(expr $versao_tratada + 1)
         
# recursão para geração dos objetos
for object in $(echo $compositeName_multiple); do

   # Gera o Common por fora do ant, já que o mesmo é apenas um zip do diretório apps do Objetos Artefatos
   if [ $object = "Common" ]; then

        rm -rf $pathBranchSOA/StpSoaApplication/Artefatos
        mv -f $pathAbsolutoMergeSOA/StpSoaApplication/Artefatos $pathBranchSOA/StpSoaApplication
        cd $svnDir/Artefatos
        echo "Caminho Common $svnDir/Artefatos"
     
        mkdir apps_tmp
        cp -rf apps apps_tmp/apps
     
        cd apps_tmp

        find apps -name ".svn" -exec rm -rf {} \;
     
        #zip -r ../Commons.jar apps
        jar cvf Commons.jar apps
    
        cp -rf Commons.jar ../ 
        cd ..    

        rm -rf apps_tmp

        cd $root
        mv $svnDir/Artefatos/Commons.jar $dir_pacote

    else
   
        ### faz move dos objetos
 
        rm -rf $svnDir/${object}
        mv -f $pathAbsolutoMergeSOA/$application/${object} $svnDir

        #### gera o pacote
        cd $svnDir
        caminhoComposite=`echo $svnDir/${object}`
        cd $caminhoComposite
        echo $caminhoComposite
 
        # Copiando o diretório Classes que contém os arquivos xmls de referência para a geração do objeto 
   	#cp -rf $root/classes $caminhoComposite/SCA-INF
   	#Gerando o pacote utilizando o ant e jdeveloper setados acima
   	#$antDir/ant -f $jdevDir/ant-sca-compile.xml
   	#$antDir/ant -f $jdevDir/ant-sca-package.xml -DcompositeDir=$caminhoComposite -DcompositeName=$object -Drevision=$version
 
        # Removendo jars antigos referentes 
        rm -rf $svnDir/$object/deploy/*.jar

        #Substituindo a variável ${pathAnt} para o path do jdev correto
        caminho="\/app\/soa12c\/soa\/bin"

        sed -i s'/${pathAnt}/'$caminho'/'g $svnDir/$object/pom.xml
        
        # Alterando a versão da build
        #versao=`cat $svnDir/project.properties | grep version | cut -f2 -d'='`
        # versao_tratada=`echo $versao | cut -f1 -d'.'`
        #next_version=$(expr $versao_tratada + 1)
        sed -i "s/version.*/version=$next_version.0/g" $svnDir/project.properties
        sed -in "1,10 s/<version>.*</<version>$next_version.0</g" $svnDir/$object/pom.xml
        #sed -i s'/<version>1.0-SNAPSHOT/<version>1.0/'g $svnDir/$object/pom.xml

        ### Gerando com Maven ###
        mvn install

        status=$?
        if [ $status != 0 ];then
               echo "Há erros de compilação na build, verifique o log apresentado acima!"
               exit 3
        fi

	# copia o pacote para o path passado por parametro
  	cd $root
        fullName=sca_$object
  	mv $svnDir/$object/deploy/*.jar $dir_pacote/$fullName.jar

	# copia o arquivo configPlan $object_  
     	   cd $caminhoComposite
     	   copia_configPlan=`ls *ambstp.xml`
     	   cp -rfp $svnDir/$object/$copia_configPlan $dir_pacote/$fullName.xml
       # Condição necessária para eliminar lixo gerados quando o objeto não tem configPlan
       if [ -d $dir_pacote/$fullName.xml ]; then
           rm -rf $dir_pacote/$fullName.xml
       fi


    fi
done
