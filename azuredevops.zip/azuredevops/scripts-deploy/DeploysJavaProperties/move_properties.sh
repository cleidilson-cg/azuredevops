#!/bin/bash

#Usage: O primeiro parametro eh o nome da pasta do properties. Por exemplo: config-ms-ecommerce
if [ -z $1 ]; then
  echo ""
  echo "Nome do pacote não foi informado" 
  echo ""
  echo "#Usage: O primeiro parametro eh o nome da pasta do properties."
  echo "Por exemplo: $0 <config-ms-ecommerce>"
  exit 1
fi

#Data usada para setar a versao do properties na pasta /appconfig/bkp/
data=`date +"%d-%d-%y-%I-%M-%S"`

pasta_properties=$1
maquina=$(hostname -a)

# O "@" serve para criar um arraylist, de outra forma, ele criaria uma string com varios pipes, e 
# La embaixo, quando precisassemos utilizar um "case" dinamico, nao funcionaria.
shopt -s extglob

#Validacao de qual maquina (homolog|prod) o script esta executando

#HOMOLOGACAO
if [[ "$maquina" =~ ^(bredt1-svwlgh01|bredt1-svwlgh02|bredt1-svwlgp07|bredt1-apwlgh01)$ ]]; then

    # O resultado de PWD sempre deve retornar no minimo uma estrutura de 4 subsiretorios. Ex: /app/deploy/scm/scriptTools/microservico/alteraproperties/, dessa forma usaremos "scm" como filtro.
    valida_path=$(pwd | cut -d / -f4)

    if [ "$valida_path" == "dev" ];  then
        
        path_to_pack_ms="/app/deploy/dev/pack_ms/"
        pathProperties="/app/domains/dev/stp_apl01dev_domain/appconfig"                      

        # Ambiente de UAT novo criado na maquina 10.0.203.121(bredt1-svwlgh01)
        elif [ "$valida_path" == "uat" ]; then

            path_to_pack_ms="/app/deploy/uat/pack_ms/"
            pathProperties="/app/domains/uat/stp_apl01uat_domain/appconfig"                  

        # Ambiente de PPRD
        elif [ "$valida_path" == "infrasoa" ]; then
            machines_to_copy=(bredt1-svwlgp08 bredt1-svwlgp07)
            path_to_pack_ms="/app/deploy/infrasoa/pack_boleto_registrado/"
            pathProperties="/app/domains/npa/stp_app01npapprd_domain/appconfig"

        
        elif [ "$valida_path" == "bugts" ]; then

            path_to_pack_ms="/app/deploy/bugts/pack_ms/"
            pathProperties="/app/domains/bugts/stp_apl01bugts_domain/appconfig"
        
        # Ambiente de UAT antigo criado na maquina 10.0.203.122(bredt1-svwlgh02)
        elif [ "$valida_path" == "scm" ]; then
            
            path_to_pack_ms="/app/deploy/scm/pack_ms/"
            pathProperties="/app/domains/npa/stp_apl01npauat_domain"


        elif [ "$valida_path" == "vp" ]; then
            path_to_pack_ms="/app/deploy/vp/pack_boleto_registrado/"
            pathProperties="/app/domains/vp/stp_apl01vppprd_domain/appconfig"

    fi  

fi



#Definicao de arrays por ambiente | Usado no case dinamico

maquinas_cc='@(bredt1-svwlgp36|bredt1-svwlgp37)'
maquinas_mc='@(bredt1-svwlgp34|bredt1-svwlgp35)'
maquinas_thp='@(bredt1-svwlgp29|bredt1-svwlgp30)'
maquinas_stb='@(bredt1-svwlgp40|bredt1-svwlgp41)'
maquinas_batch='@(bredt1-svwlgp24|bredt1-svwlgp25|bredt1-svwlgp26|bredt1-svwlgp27|bredt1-svwlgp28)'
maquinas_online='@(bredt1-svwlgp38|bredt1-svwlgp39)'
maquinas_vp='@(bredt1-svwlgp20.cgmp-osa.com.br|bredt1-svwlgp21.cgmp-osa.com.br)'
maquinas_vo01='@(bredt1-svadmp10)'
maquinas_vo03='@(bredt1-svadmp12)'
maquinas_apl01npa='@(bredt1-svadmp07)'


#Criando um array com todas as maquinas informadas na criacao do array anterior
todas_maquinas=("${maquinas_cc[@]}" "${maquinas_thp[@]}" "${maquinas_mc[@]}" "${maquinas_batch[@]}" "${maquinas_vp[@]}" "${maquinas_online[@]}")


#Pegar o nome da maquina aonde o script esta executando
# "-a" esta sendo usado apra evitar pegar o nome do dominio
# Dependendo da versao do linux, o comando hostname -a retorna mais de uma campo, por isso foi usado o "awk" para o campo $1. 
maquina_atual=`hostname -a |awk '{print $1}'`
 
case ${maquina_atual} in
    $maquinas_batch)
        machines_to_copy=('bredt1-svwlgp24 bredt1-svwlgp25 bredt1-svwlgp26 bredt1-svwlgp27 bredt1-svwlgp28')
        path_to_pack_ms="/app/deploy/bat/pack_ms"
        pathProperties="/app/domains/bat/stp_apl01bat_domain/appconfig"        
        ;;
    $maquinas_apl01npa)
        path_to_pack_ms="/app/deploy/prd/pack_ms"
        pathProperties="/app/domains/npa/stp_apl01npa_domain/appconfig"        
        ;;
    $maquinas_cc)        
        machines_to_copy=('bredt1-svwlgp34 bredt1-svwlgp35')
        path_to_pack_ms="/app/deploy/cc/pack_ms"
        pathProperties="/app/domains/cc/stp_apl01cc_domain/appconfig"        
        ;;
    $maquinas_mc)
        machines_to_copy=('bredt1-svwlgp36 bredt1-svwlgp37')
        path_to_pack_ms="/app/deploy/mc/pack_ms"
        pathProperties="/app/domains/mc/stp_apl01mc_domain/appconfig"
        ;;
    $maquinas_thp)
        machines_to_copy=('bredt1-svwlgp29 bredt1-svwlgp30')
        path_to_pack_ms="/app/deploy/thp/pack_ms"
        pathProperties="/app/domains/thp/stp_apl01thp_domain/appconfig"        
        ;;
    $maquinas_thp)
        machines_to_copy=('bredt1-svwlgp40 bredt1-svwlgp41')
        path_to_pack_ms="/app/deploy/thp/pack_ms"
        pathProperties="/app/domains/thp/stp_apl01thp_domain/appconfig"        
        ;;
    $maquinas_vp)
        #Como sao 'torres' diferentes para cada maquina, nao eh necessario fazer SCP, apenas o move, por isso esta comentado abaixo
        #machines_to_copy=('bredt1-svwlgp20.cgmp-osa.com.br bredt1-svwlgp21.cgmp-osa.com.br')        
        # VP01 e VP02 tem nomenclaturas de dominio diferentes(aplvp01 e aplvp02). Para "normalizar" isso, foi criado um link simbólico para aplvp01 na maquina do vp02"
        path_to_pack_ms="/app/deploy/vp/pack_ms"
        pathProperties="/app/domains/vp/stp_apl01vp_domain/appconfig"
        ;;
    $maquinas_online)
        machines_to_copy=('bredt1-svwlgp38 bredt1-svwlgp39')
        path_to_pack_ms="/app/deploy/prd/pack_ms"
        pathProperties="/app/domains/npa/stp_apl02npa_domain/appconfig"
        ;;
    $maquinas_vo01)
        machines_to_copy=('bredt1-apwlgp02')
        path_to_pack_ms="/app/deploy/virtual02/pack_ms"
        pathProperties="/app/domains/npa/stp_apl03npa_domain/appconfig"
        ;;
    $maquinas_vo03)
        machines_to_copy=('bredt1-apwlgp04')
        path_to_pack_ms="/app/deploy/virtual02/pack_ms"
        pathProperties="/app/domains/npa/stp_apl03npa_domain/appconfig"
        ;;
        *)
        echo "Não foi possivel setar os paths na maquina: [$maquina_atual] . VERIFICAR!!!!!!!!!!!" >> /tmp/deploy_alterar_properties.log;
esac




move_properties(){

# Validar existencia da pasta "/appconfig/bkp/, se nao existir, criar ela." 
if [ ! -d $pathProperties/bkp/ ]; then

    echo "Pasta $pathProperties/bkp/ nao existe. Criando..."
    mkdir -v $pathProperties/bkp/

fi

#Valida se ja existe a pasta config-ms* dentro de appconfig, se existir, mover o atual para a pasta de bkp
if [ -d $pathProperties/$pasta_properties ]; then
    mv -v $pathProperties/$pasta_properties $pathProperties/bkp/$pasta_properties-$data
fi

#movendo a pasta de config dentro de pack_ms para $DOMAIN/appconfig/
mv -v $path_to_pack_ms/$pasta_properties $pathProperties/

for maquina_destino in $machines_to_copy;  do

    if [ "$maquina" == "$maquina_destino" ]; then

    echo "Maquina atual e maquina destino sao a mesma maquina, nao eh necessario fazer o scp."
    
    else
        scp -r $pathProperties/$pasta_properties/ $maquina_destino:$pathProperties/; 
    fi
done

}      


########################### MAIN ###########################

echo ########################################
echo ######### Movendo properties ###########
echo ########################################


move_properties


echo ########################################
echo ######### Properties movidos ###########
echo ########################################
