#!/bin/bash
################# SETANDO VARIAVEIS DE AMBIENTE #################
# TODO: Validar a necessidade do "maquina" e "maquina_atual"
# TODO: Adicionar maquinas do VP PPRD e do GTO HOMOLOG E PROD
# TODO: Colocar padrao nas pastas "pack_ms_apl" para serem "pack_ms" - Feito
maquina=$(hostname -a)
# O "@" serve para criar um arraylist, de outra forma, ele criaria uma string com varios pipes, e 
# La embaixo, quando precisassemos utilizar um "case" dinamico, nao funcionaria.
shopt -s extglob
#Validacao de qual maquina (homolog|prod) o script esta executando
#HOMOLOGACAO
if [[ "$maquina" =~ ^(bredt1-svwlgh01|bredt1-svwlgh02|bredt1-svwlgp07|bredt1-apwlgh01)$ ]]; then
    valida_path=$(pwd | cut -d / -f4)
    if [ "$valida_path" == "dev" ];  then
        
        pathPacote="/app/deploy/dev/pack_ms/"
        endpoint_properties="/app/deploy/dev/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/dev/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        elif [ "$valida_path" == "uat" ]; then
            pathPacote="/app/deploy/uat/pack_ms/"
            endpoint_properties="/app/deploy/uat/scriptTools/microservico/alteraproperties/endpoint.properties"
            endpoint_properties_externo="/app/deploy/uat/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        
        elif [ "$valida_path" == "infrasoa" ]; then
            pathPacote="/app/deploy/infrasoa/pack_boleto_registrado/"
            endpoint_properties="/app/deploy/infrasoa/scriptTools/microservico/alteraproperties/endpoint.properties"
            endpoint_properties_externo="/app/deploy/infrasoa/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        
        elif [ "$valida_path" == "pprd" ]; then
            pathPacote="/app/deploy/pprd/pack_ms/"
            endpoint_properties="/app/deploy/pprd/scriptTools/microservico/alteraproperties/endpoint.properties"
            endpoint_properties_externo="/app/deploy/pprd/scriptTools/microservico/alteraproperties/endpoint_externo.properties"        
        elif [ "$valida_path" == "bugts" ]; then
            pathPacote="/app/deploy/bugts/pack_ms/"
            endpoint_properties="/app/deploy/bugts/scriptTools/microservico/alteraproperties/endpoint.properties"
            endpoint_properties_externo="/app/deploy/bugts/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
    fi  
fi
#Definicao de arrays para conseguir fazer um case dinamico
maquinas_cc='@(bredt1-svwlgp36|bredt1-svwlgp37)'
maquinas_mc='@(bredt1-svwlgp34|bredt1-svwlgp35)'
maquinas_thp='@(bredt1-svwlgp29|bredt1-svwlgp30)'
maquinas_stb='@(bredt1-svwlgp40|bredt1-svwlgp41)'
maquinas_batch='@(bredt1-svwlgp24|bredt1-svwlgp25|bredt1-svwlgp26|bredt1-svwlgp27|bredt1-svwlgp28)'
maquinas_online='@(bredt1-svwlgp38|bredt1-svwlgp39)'
maquinas_vp='@(bredt1-svwlgp42|bredt1-svwlgp43)'
maquinas_vo01='@(bredt1-svadmp10)'
maquinas_vo03='@(bredt1-svadmp12)'
maquinas_apl01npa='@(bredt1-svadmp07)'
#Criando um array com todas as maquinas informadas na criacao do array anterior
todas_maquinas=("${maquinas_cc[@]}" "${maquinas_thp[@]}" "${maquinas_mc[@]}" "${maquinas_batch[@]}" "${maquinas_vp[@]}" "${maquinas_online[@]}")
#Pegar o nome da maquina aonde o script esta executando
# "-a" esta sendo usado apra evitar pegar o nome do dominio
# Dependendo da versao do linux, o comando hostname -a retorna mais de uma campo, por isso foi usado o "awk" para o campo $1. 
maquina_atual=`hostname -a |awk '{print $1}'`
 
case ${maquina_atual} in
    $maquinas_batch)
        pathPacote="/app/deploy/bat/pack_ms/"
        endpoint_properties="/app/deploy/bat/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/bat/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_apl01npa)
        pathPacote="/app/deploy/prd/pack_ms/"
        endpoint_properties="/app/deploy/prd/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/prd/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_cc)
        pathPacote="/app/deploy/cc/pack_ms/"
        endpoint_properties="/app/deploy/cc/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/cc/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_mc)
        pathPacote="/app/deploy/mc/pack_ms/"
        endpoint_properties="/app/deploy/mc/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/mc/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_thp)
        pathPacote="/app/deploy/thp/pack_ms/"
        endpoint_properties="/app/deploy/thp/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/thp/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_stb)
        pathPacote="/app/deploy/stb/pack_ms/"
        endpoint_properties="/app/deploy/stb/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/stb/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_vp)
        pathPacote="/app/deploy/vp/pack_ms/"
        endpoint_properties="/app/deploy/vp/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/vp/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_online)
        pathPacote="/app/deploy/prd/pack_ms/"
        endpoint_properties="/app/deploy/prd/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/prd/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_vo01)
        pathPacote="/app/deploy/virtual02/pack_ms/"
        endpoint_properties="/app/deploy/virtual02/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/virtual02/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
    $maquinas_vo03)
        pathPacote="/app/deploy/virtual02/pack_ms/"
        endpoint_properties="/app/deploy/virtual02/scriptTools/microservico/alteraproperties/endpoint.properties"
        endpoint_properties_externo="/app/deploy/virtual02/scriptTools/microservico/alteraproperties/endpoint_externo.properties"
        ;;
        *)
        echo "Não foi possivel setar os paths na maquina: [$maquina_atual] . VERIFICAR!!!!!!!!!!!" >> /tmp/deploy_alterar_properties.log;
esac
########################### MAIN ####################################
for config in $( cd $pathPacote && ls -d config*); do
    #Em PPRD adiante, o properties vem dentro de um arquivo config-ms.zip
    echo "Procurando por arquivo config-ms.zip"
    zipFile=$(ls $pathPacote/config-*.zip )
        
    #Em DEV/QA/BUGTS/NAO, o properties vem dentro de uma pasta, entao, estamos pegando o ZIP(caso tenha) e retirando a extensao
    echo "Procurando por pasta config-ms"    
    nome_pasta_config=${config%*.zip}
    
    #Caso tenha um zip, eh necessario fazer o unzip do arquivo e colocar o seu conteudo na pasta config-ms-aplicacao
    if [ ! -z "$zipFile"  ]; then
    
        echo ""
        echo "Pacote ZIP identificado" 
        echo "" 
            
            #nome_pasta_config=${config%*.zip}
            mkdir $pathPacote$nome_pasta_config
            mv $pathPacote$config $pathPacote$nome_pasta_config/
            echo "Unzip do $config"
            unzip $pathPacote$nome_pasta_config/$config -d $pathPacote$nome_pasta_config/ 
            rm $pathPacote$nome_pasta_config/$config
            
    fi
    
    echo ""    
    echo "Tirando caracteres especiais provenientes do WINDOWS"
    dos2unix $pathPacote*/*.properties > /dev/null 2>&1
    echo ""
    #Caso exista arquivos properties, seguir com o script
    if [ ! -z "$(ls $pathPacote*/*.properties)" ]; then
        echo "Iniciando replace no arquivo PROPERTIES"
        #Monta string para egrep com as chaves ex.: "URL_NAO|URL_APL|URL_DOTNET|URL_CBILL|URL_OSB"
        # O SED abaixo serve para substituir o final de linha por um "|". 
        chaves_egrep=$(cat $endpoint_properties $endpoint_properties_externo |cut -d= -f1 |sed ':a;N;$!ba;s/\n/|/g')
        #String procurando as chaves nos artefatos
        valida_chaves=$(egrep -iR "http://|https://|$chaves_egrep" $pathPacote)
        if [ -n "$valida_chaves" ]; then
            for linha in $(cat $endpoint_properties $endpoint_properties_externo); do
                chave_url=$(echo $linha |cut -d= -f1)
                endpoint_destino=$(echo $linha | cut -d= -f2)
                sed -i "s|$chave_url\$|$endpoint_destino|g" $pathPacote$nome_pasta_config/*.properties;
                if [ $chave_url == "DIR_CONFIG" ]; then
                    sed -i "s|$chave_url|$endpoint_destino|g" $pathPacote$nome_pasta_config/*.properties;
                fi
            done
            echo "Replace no Arquivo properties finalizado" 
    
        else
            echo ""
            echo "Não encontrado chaves dentro do properties. VALIDAR SE O PROPERTIES ESTA NO PADRÃO."   
        fi
    fi
    
done