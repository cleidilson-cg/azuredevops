#!/bin/bash

pythonEnv="/home/DTC/svc_tfsservice/kafka/kafka-admin"
repo=`pwd`


set_env() {
  source $pythonEnv/bin/activate
}

install_kafka_python_lib() {
  pip install kafka-python
}

clone_kafkatopics_repo() {
    git clone ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/flt-kafka-topics
}

create_topic() {
    cd $pythonEnv
    python3 main.py criar_topicos --ambiente $env --arquivo_topicos $repo/$topic/$topicfile
}

#setando o ambiente

set_env

# Criando os tópicos

create_topic

 status=$?

    if [ $status != 0 ]; then
        echo "Erro ao criar o topico $topicFile/$topic..."
        exit 3
    fi
