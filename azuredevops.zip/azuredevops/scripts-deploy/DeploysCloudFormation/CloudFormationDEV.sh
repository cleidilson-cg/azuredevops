#!/bin/bash
echo PROFILE_SCRIPT:${awsProf}
awsProf=$(echo "$awsProf" | sed -e s/\'//g)
bucket=$(echo "${bucket}" | sed -e s/\'//g)
#Import NodeJS
geracao_output() {
    echo "Executando o JS para geracao do OUTPUT"
    sed -i "s/#UserID/$userAwsId/"g template.json
    node cloud-formation-creator.js $api

    release=`cat ${api}/input.json | grep "Release" | cut -d'"' -f4`
    regiao=`cat ${api}/input.json | grep "Regiao" | cut -d'"' -f4`

    if [ "${ambiente}" == "parcerias-dev" ]; then
        sed -i 's/#AMBIENTE#/parcerias-dev/'g ${api}/output.json
    else
        sed -i 's/#AMBIENTE#/dev/'g ${api}/output.json
    fi
    #sed -i 's/#AMBIENTE#/dev/'g ${api}/output.json ##|| true
    #sed -i 's/#AMBIENTE#/parcerias-dev/'g ${api}/output.json ##|| true
    #ambiente=$(echo "$ambiente" | sed -e s/\'//g)
    #sed -i `s/\#AMBIENTE#/${ambiente}/`g ${api}/output.json

    echo "Conteudo do OUTPUT a ser executado"
    #cat $api/output.json
}

atualizar_criar_api_com_regiao() {
    echo "atualizar/criar api com regiao"

    echo aws cloudformation deploy --template-file ${api}/output.json --stack-name ${api}0JENKINS --s3-bucket ${bucket} --profile ${awsProf} --region $regiao
    aws cloudformation deploy --template-file ${api}/output.json --stack-name ${api}0JENKINS --s3-bucket ${bucket} --profile ${awsProf} --region $regiao
    
}

atualizar_criar_api() {
    echo "atualizar/criar api"
    echo aws cloudformation deploy --template-file ${api}/output.json --stack-name ${api}0JENKINS --s3-bucket ${bucket} --profile ${awsProf}
    aws cloudformation deploy --template-file ${api}/output.json --stack-name ${api}0JENKINS --s3-bucket ${bucket} --profile ${awsProf}

}

atualizar_criar_stage() {
    echo "atualizar/criar stage"
    #aws apigateway get-rest-apis --profile ${awsProf} > apis.json
    aws apigateway get-rest-apis --query 'items[?name==`'${api}'`]'.id  --profile ${awsProf} > apis.json

    #idApi=`cat apis.json | grep -B 1 '"'${api}'"' | grep '"id"' | cut -d'"' -f4`
    idApi=`cat apis.json | grep -B 1 ] | cut -d '"' -f2 | sed '$d'`
    echo "nome API $api"
    echo "id API $idApi"       		
    
    if [[ -f $api/${stage}_DEV.json ]]; then
        sed -i "s/#APIid/$idApi/"g $api/${stage}_DEV.json
        sed -i 's/#HOST/billinghom.cgmp-osa.com.br/'g $api/${stage}_DEV.json
        sed -i 's/#PORT/42001/'g $api/${stage}_DEV.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}_DEV.json --profile ${awsProf}
    else
        sed -i "s/#APIid/$idApi/"g $api/${stage}.json
        sed -i 's/#HOST/billinghom.cgmp-osa.com.br/'g $api/${stage}.json
        sed -i 's/#PORT/42001/'g $api/${stage}.json
        
        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}.json --profile ${awsProf}
    fi                
    

    if [[ $usagePlanFlag == "true" ]]; then
        echo "##############"
        echo "UsagePlan"
        echo "##############"
        aws apigateway update-usage-plan --usage-plan-id ${usagePlanId} --patch-operations op=add,path=/apiStages,value=${idApi}:${stage} --profile ${awsProf}
        
    fi

}

atualizar_criar_stage_com_regiao() {
    echo "atualizar/criar stage com regiao"
	
    #aws apigateway get-rest-apis --profile ${awsProf} --region $regiao > apis.json
    aws apigateway get-rest-apis --query 'items[?name==`'${api}'`]'.id --profile ${awsProf} --region $regiao > apis.json
	#idApi=`cat apis.json | grep -B 1 '"'${api}'"' | grep '"id"' | cut -d'"' -f4`
    idApi=`cat apis.json | grep -B 1 ] | cut -d '"' -f2 | sed '$d'`
    echo "nome API $api"
    echo "id API $idApi"       		
    
    if [[ -f $api/${stage}_DEV.json ]]; then
        sed -i "s/#APIid/$idApi/"g $api/${stage}_DEV.json
        sed -i 's/#HOST/billinghom.cgmp-osa.com.br/'g $api/${stage}_DEV.json
        sed -i 's/#PORT/42001/'g $api/${stage}_DEV.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}_DEV.json --profile ${awsProf} --region $regiao
    else
        sed -i "s/#APIid/$idApi/"g $api/${stage}.json
        sed -i 's/#HOST/billinghom.cgmp-osa.com.br/'g $api/${stage}.json
        sed -i 's/#PORT/42001/'g $api/${stage}.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}.json --profile ${awsProf} --region $regiao
    fi
            
    


    if [[ $usagePlanFlag == "true" ]]; then
        echo "##############"
        echo "UsagePlan"
        echo "##############"
        aws apigateway update-usage-plan --usage-plan-id ${usagePlanId} --patch-operations op=add,path=/apiStages,value=${idApi}:${stage} --profile ${awsProf} --region $regiao
        
    fi
}

######################## MAIN ########################

echo $regiao
echo ${regiao}

#Remocendo caracteres especiais que nao sejam letras maiusculas
#Por algum motivo, a variavel estava vindo com apóstrofos e uma barra invertida.
#awsProf=$(echo "$awsProf" | sed -e 's/[^A-Z]//g')
awsProf=$(echo "$awsProf" | sed -e s/\'//g)

#CRIANDO PACOTE.ZIP PARA PUBLICAR COMO ARTEFATO
zip -r $api.zip cloud-formation-creator.js template.json templatews.json ${api}

#GERANDO OUTPUT
geracao_output

echo
echo
echo "#############################################"
echo "Executando o AWS CLI com o OUTPUT formado"
echo "#############################################"
#Recuperar operacoes informadas na execucao do jenkins
operation_multiple=$(echo "${operacao//,}")

for operation in $(echo ${operation_multiple}); do
    if [[ $(echo $regiao | grep -i "us-east-1") ]]; then
        if [[ $operation == "atualizar-criar-api" ]]; then
            echo             
            atualizar_criar_api_com-regiao 
            echo 
        elif [[ $operation == "atualizar-criar-stage" ]]; then
            echo 
            atualizar_criar_stage_com_regiao
            echo 
        fi
    else
        if [[ $operation == "atualizar-criar-api" ]]; then
            echo 
            atualizar_criar_api
            echo 
        elif [[ $operation == "atualizar-criar-stage" ]]; then
            echo 
            atualizar_criar_stage
            echo 
        fi
    fi
done