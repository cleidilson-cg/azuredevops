#!/bin/bash
set -x 
bucket=$(echo "${bucket}" | sed -e s/\'//g)
userAwsId=$(echo "${userAwsId}" | sed -e s/\'//g)
#Import NodeJS
geracao_output() {
    echo "Executando o JS para geracao do OUTPUT"
    sed -i "s/#UserID/$userAwsId/"g template.json
    node cloud-formation-creator.js $api
    
    release=`cat ${api}/input.json | grep "Release" | cut -d'"' -f4`
    regiao=`cat ${api}/input.json | grep "Regiao" | cut -d'"' -f4` 

    if [ "${ambiente}" == "parcerias-prod" ]; then
        sed -i 's/#AMBIENTE#/parcerias-prod/'g ${api}/output.json 
    else
        sed -i 's/#AMBIENTE#/prod/'g ${api}/output.json
    fi

    #sed -i 's/#AMBIENTE#/prod/'g ${api}/output.json   
    
    echo "Executando o AWS CLI com o OUTPUT formado"
    cat ${api}/output.json
}

#Endpoints 
    #A variavel estava vindo com espaco, esse comando eh para retirar apenas espacos em branco da variavel
    endpoint=$(echo "$endpoint" |sed 's/[[:space:]]//g')

    if [[ ${endpoint} == "Abastece" ]];then    
    	urlEndpoint="abastecesvc.semparar.com.br"    
    elif [[ ${endpoint} == "CallCenterURA" ]];then
    	urlEndpoint="atendimentosvc.semparar.com.br"   
    elif [[ ${endpoint} == "Varejo" ]];then
    	urlEndpoint="atendimentovarejosvc.semparar.com.br"
    elif [[ ${endpoint} == "Autorizador" ]];then
    	urlEndpoint="autorizacaosvc.semparar.com.br"
    elif [[ ${endpoint} == "ValePedagio" ]];then
    	urlEndpoint="b2bsvc.semparar.com.br"
    elif [[ ${endpoint} == "CapturadeVenda" ]];then
    	urlEndpoint="capturavendasvc.semparar.com.br"
    elif [[ ${endpoint} == "BankPartnership" ]];then
    	urlEndpoint="fidcccbsvc.semparar.com.br"
    elif [[ ${endpoint} == "APPMinhaConta" ]];then
    	urlEndpoint="mcappsvc.semparar.com.br"
    elif [[ ${endpoint} == "Movida" ]];then
    	urlEndpoint="movidasvc.semparar.com.br"
    elif [[ ${endpoint} == "McDonalds" ]];then
    	urlEndpoint="multiprodutosvc.semparar.com.br"
    elif [[ ${endpoint} == "EasySalesNumclick" ]];then
    	urlEndpoint="numclicksvc.semparar.com.br"
    elif [[ ${endpoint} == "Boleto" ]];then
    	urlEndpoint="boletosvc.semparar.com.br"
    elif [[ ${endpoint} == "b2b-faturas" ]];then
    	urlEndpoint="prod.apisemparar.com.br/b2b-faturas/v1/"
    elif [[ ${endpoint} == "b2b-veiculos" ]];then
    	urlEndpoint="prod.apisemparar.com.br/b2b-veiculos/v1/"
    fi
    
    echo urlEndpoint ${urlEndpoint}

atualizar_criar_api_com_regiao(){
    echo "#############################################"
    echo "atualizar/criar api com REGIAO"
    echo "#############################################"    
    
    aws cloudformation deploy --template-file ${api}/output.json --stack-name ${api}0JENKINS --s3-bucket ${bucket} --profile ${awsProf} --region $regiao
}  

atualizar_criar_api(){
    echo "#############################################"
    echo "atualizar/criar api Default"
    echo "#############################################"
    
    aws cloudformation deploy --template-file ${api}/output.json --stack-name ${api}0JENKINS --s3-bucket ${bucket} --profile ${awsProf}
}

atualizar_criar_stage_com_regiao() {
    echo "#############################################"
    echo "atualizar/criar stage com REGIAO"
    echo "#############################################"
    
    echo "aws apigateway get-rest-apis --profile ${awsProf} > apis.json"
    aws apigateway get-rest-apis --query 'items[?name==`'${api}'`]'.id  --profile ${awsProf} > apis.json

    #idApi=`cat apis.json | grep -B 1 '"'${api}'"' | grep '"id"' | cut -d'"' -f4`
    idApi=`cat apis.json | grep -B 1 ] | cut -d '"' -f2 | sed '$d'`
    echo "nome API $api"
    echo "id API $idApi" 

    if [[ -f "$api/${stage}_PRD.json" ]]; then
        sed -i "s/#apiid/$idApi/"g $api/${stage}_PRD.json
        sed -i "s/#HOST/$urlEndpoint/"g $api/${stage}_PRD.json
        sed -i 's/#PORT/80/'g $api/${stage}_PRD.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}_PRD.json --profile ${awsProf} --region $regiao
    else
        sed -i "s/#apiid/$idApi/"g $api/${stage}.json
        sed -i "s/#HOST/$urlEndpoint/"g $api/${stage}.json
        sed -i 's/#PORT/80/'g $api/${stage}.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}.json --profile ${awsProf} --region $regiao
    fi
    
    if [[ $usagePlanFlag == "true" ]]; then
        echo "##############"
        echo "UsagePlan"
        echo "##############"
        aws apigateway update-usage-plan --usage-plan-id ${usagePlanId} --patch-operations op=add,path=/apiStages,value=${idApi}:${stage} --profile ${awsProf}
    fi  

}

atualizar_criar_stage() {
    echo "#############################################"
    echo "atualizar/criar stage Default"
    echo "#############################################"

    aws apigateway get-rest-apis --query 'items[?name==`'${api}'`]'.id  --profile ${awsProf} > apis.json

    idApi=`cat apis.json | grep -B 1 ] | cut -d '"' -f2 | sed '$d'`
    echo "nome API $api"
    echo "id API $idApi"  

    if [[ -f "$api/${stage}_PRD.json" ]]; then
        sed -i "s/#apiid/${idApi}/"g $api/${stage}_PRD.json
        sed -i "s/#HOST/${urlEndpoint}/"g $api/${stage}_PRD.json
        sed -i 's/#PORT/80/'g $api/${stage}_PRD.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}_PRD.json --profile ${awsProf}
    else
        sed -i "s/#apiid/${idApi}/"g $api/${stage}.json
        sed -i "s/#HOST/${urlEndpoint}/"g $api/${stage}.json
        sed -i 's/#PORT/80/'g $api/${stage}.json

        aws apigateway create-deployment --rest-api-id ${idApi} --cli-input-json fileb://$api/${stage}.json --profile ${awsProf}
    fi

    if [[ $usagePlanFlag == "true" ]]; then
        echo "##############"
        echo "UsagePlan"
        echo "##############"
        aws apigateway update-usage-plan --usage-plan-id ${usagePlanId} --patch-operations op=add,path=/apiStages,value=${idApi}:${stage} --profile ${awsProf}
    fi
}
######################## MAIN ########################

set -x 

echo ${api}
echo ${regiao}
echo ${endpoint}
echo ${idApi}
echo ${stage}

#GERANDO OUTPUT
geracao_output

echo "Executando o AWS CLI com o OUTPUT formado"
#Recuperar operacoes informadas na execucao do jenkins
operation_multiple=$(echo "${operacao//,}")

for operation in $(echo ${operation_multiple}); do
    if [[ $(echo $regiao | grep -i "us-east-1") ]]; then
        if [[ $operation == "atualizar-criar-api" ]]; then
            atualizar_criar_api_com_regiao
        elif [[ $operation == "atualizar-criar-stage" ]]; then
            atualizar_criar_stage_com_regiao
        fi
    else
        if [[ $operation == "atualizar-criar-api" ]]; then
            atualizar_criar_api
        elif [[ $operation == "atualizar-criar-stage" ]]; then
            atualizar_criar_stage
        fi
    fi
done