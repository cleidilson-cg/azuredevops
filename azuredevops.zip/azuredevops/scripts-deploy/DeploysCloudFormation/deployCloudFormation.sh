#!/bin/bash
set -x
api=$(echo "$api" | sed -e s/\'//g)
for conta in $(cat $localpath/CloudformationAPI/$api/api-profile-env); do
    
    pathConfig="$localpath/scripts-deploy/DeploysCloudFormation/config/$branch/$conta"
    ambiente=$(cat $pathConfig | grep ambiente | cut -b 10- | tr -d \")
    awsProf=$(cat $pathConfig | grep awsProf | cut -b 9- | tr -d \")
    bucket=$(aws s3api list-buckets --profile $awsProf | jq -r '.Buckets[].Name' | grep "^deploy-*")
    userAwsId=$(aws sts get-caller-identity --profile $awsProf | grep "Account" | cut -d'"' -f4)
    usagePlanId=$(aws apigateway get-usage-plans --profile $awsProf --query "items[?name=='$usagePlanName'].id" | grep '[a-zA-Z0-9]' | cut -d '"' -f2)

    bucket=$(echo "$bucket" | sed -e s/\'//g)
    ambiente=$(echo "$ambiente" | sed -e s/\'//g)
    geracao_output() {
        echo "Executando o JS para geracao do OUTPUT"
        sed -i "s/#UserID/$userAwsId/"g template.json
        node cloud-formation-creator.js $api

        sed -i "s/#AMBIENTE#/$ambiente/"g $api/output.json
        echo "Conteudo do OUTPUT a ser executado"
    }


    #Endpoints 
    #A variavel estava vindo com espaco, esse comando eh para retirar apenas espacos em branco da variavel
    endpoint=$(echo "$endpoint" |sed 's/[[:space:]]//g')

    if [[ $(echo $ambiente | grep -o "prod") == "prod" ]];then
        if [[ $endpoint == "Abastece" ]];then
            urlEndpoint="abastecesvc.semparar.com.br"
        elif [[ $endpoint == "CallCenterURA" ]];then
            urlEndpoint="atendimentosvc.semparar.com.br"   
        elif [[ $endpoint == "Varejo" ]];then
            urlEndpoint="atendimentovarejosvc.semparar.com.br"
        elif [[ $endpoint == "Autorizador" ]];then
            urlEndpoint="autorizacaosvc.semparar.com.br"
        elif [[ $endpoint == "ValePedagio" ]];then
            urlEndpoint="b2bsvc.semparar.com.br"
        elif [[ $endpoint == "CapturadeVenda" ]];then
            urlEndpoint="capturavendasvc.semparar.com.br"
        elif [[ $endpoint == "BankPartnership" ]];then
            urlEndpoint="fidcccbsvc.semparar.com.br"
        elif [[ $endpoint == "APPMinhaConta" ]];then
            urlEndpoint="mcappsvc.semparar.com.br"
        elif [[ $endpoint == "Movida" ]];then
            urlEndpoint="movidasvc.semparar.com.br"
        elif [[ $endpoint == "McDonalds" ]];then
            urlEndpoint="multiprodutosvc.semparar.com.br"
        elif [[ $endpoint == "EasySalesNumclick" ]];then
            urlEndpoint="numclicksvc.semparar.com.br"
        elif [[ $endpoint == "Boleto" ]];then
            urlEndpoint="boletosvc.semparar.com.br"
        elif [[ $endpoint == "b2b-faturas" ]];then
            urlEndpoint="prod.apisemparar.com.br/b2b-faturas/v1/"
        elif [[ $endpoint == "b2b-veiculos" ]];then
            urlEndpoint="prod.apisemparar.com.br/b2b-veiculos/v1/"
        fi
        port="80"
    else
        urlEndpoint="billinghom.cgmp-osa.com.br"
        port="42001"
    fi
        
    echo urlEndpoint $urlEndpoint

    atualizar_criar_api_com_regiao() {
        echo "atualizar/criar api com regiao"

        echo aws cloudformation deploy --template-file $api/output.json --stack-name $api"0JENKINS" --s3-bucket $bucket --profile $awsProf --region $regiao
        aws cloudformation deploy --template-file $api/output.json --stack-name $api"0JENKINS" --s3-bucket $bucket --profile $awsProf --region $regiao
        
    }

    atualizar_criar_api() {
        echo "atualizar/criar api"
        echo aws cloudformation deploy --template-file $api/output.json --stack-name $api"0JENKINS" --s3-bucket $bucket --profile $awsProf
        aws cloudformation deploy --template-file $api/output.json --stack-name $api"0JENKINS" --s3-bucket $bucket --profile $awsProf

    }

    atualizar_criar_stage() {
        echo "atualizar/criar stage"
        aws apigateway get-rest-apis --query 'items[?name==`'$api'`]'.id  --profile $awsProf > apis.json
        idApi=`cat apis.json | grep -B 1 ] | cut -d '"' -f2 | sed '$d'`
        echo "nome API $api"
        echo "id API $idApi"       		
        
        sed -i "s/#APIid/$idApi/"g $api/$stage.json
        sed -i "s/#HOST/$urlEndpoint/"g $api/$stage.json
        sed -i "s/#PORT/$port/"g $api/$stage.json
            
        aws apigateway create-deployment --rest-api-id $idApi --cli-input-json fileb://$api/$stage.json --profile $awsProf          
        

        if [[ $usagePlanFlag == "true" ]]; then
            echo "##############"
            echo "UsagePlan"
            echo "##############"
            aws apigateway update-usage-plan --usage-plan-id $usagePlanId --patch-operations op=add,path=/apiStages,value=$idApi:$stage --profile $awsProf
            
        fi

    }

    atualizar_criar_stage_com_regiao() {
        echo "atualizar/criar stage com regiao"

        aws apigateway get-rest-apis --query 'items[?name==`'$api'`]'.id --profile $awsProf --region $regiao > apis.json

        idApi=`cat apis.json | grep -B 1 ] | cut -d '"' -f2 | sed '$d'`
        echo "nome API $api"
        echo "id API $idApi"       		
        
        sed -i "s/#APIid/$idApi/"g $api/$stage.json
        sed -i "s/#HOST/$urlEndpoint/"g $api/$stage.json
        sed -i "s/#PORT/$port/"g $api/$stage.json

        aws apigateway create-deployment --rest-api-id $idApi --cli-input-json fileb://$api/$stage.json --profile $awsProf --region $regiao
        
        if [[ $usagePlanFlag == "true" ]]; then
            echo "##############"
            echo "UsagePlan"
            echo "##############"
            aws apigateway update-usage-plan --usage-plan-id $usagePlanId --patch-operations op=add,path=/apiStages,value=$idApi:$stage --profile $awsProf --region $regiao
            
        fi
    }

    ######################## MAIN ########################
    awsProf=$(echo "$awsProf" | sed -e s/\'//g)

    #CRIANDO PACOTE.ZIP PARA PUBLICAR COMO ARTEFATO
    zip -r $api.zip cloud-formation-creator.js template.json templatews.json $api

    #GERANDO OUTPUT
    geracao_output

    echo "#############################################"
    echo "Executando o AWS CLI com o OUTPUT formado"
    echo "#############################################"

    operation_multiple=$(echo "${operacao//,}")

    for operation in $(echo $operation_multiple); do
        if [[ $(echo $regiao | grep -i "us-east-1") ]]; then
            if [[ $operation == "atualizar-criar-api" ]]; then
                echo             
                atualizar_criar_api_com-regiao 
                echo 
            elif [[ $operation == "atualizar-criar-stage" ]]; then
                echo 
                atualizar_criar_stage_com_regiao
                echo 
            fi
        else
            if [[ $operation == "atualizar-criar-api" ]]; then
                echo 
                atualizar_criar_api
                echo 
            elif [[ $operation == "atualizar-criar-stage" ]]; then
                echo 
                atualizar_criar_stage
                echo 
            fi
        fi
    done
done