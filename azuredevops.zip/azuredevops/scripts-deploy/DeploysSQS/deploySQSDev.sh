#!/bin/bash
awsProf=$1
release=`cat sqs.$arquivo.json | grep "release" | cut -d'"' -f4`
userAwsId=`aws sts get-caller-identity --profile DEV | grep "Account" | cut -d'"' -f4`
sed -i "s/#userID/$userAwsId/"g sqs.${arquivo}.output.json

aws cloudformation deploy --template-file sqs.${arquivo}.output.json --stack-name SQS0${arquivo} --profile $awsProf