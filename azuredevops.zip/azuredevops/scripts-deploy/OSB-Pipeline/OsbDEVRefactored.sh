#!/bin/bash


variaveis() {    

    package_dir=$1
    listaArtefatos=$2
    branch=$3
    settingsFile12c=$4
    
    dir_projeto="$package_dir"  
    projeto="OSB-DEV"
    dirWorkspace="${dir_projeto}/${projeto}"
    dirBuildPincado="${dirWorkspace}/buildPincado"
    dirBuild="${dirWorkspace}/build"    
    artefatos=`ls $listaArtefatos | cut -f6 -d"/"`    
    multiple_group=`cat $listaArtefatos | cut -f2 -d"/" | sort | uniq`
    alterar_configuration=`echo $multiple_group | tr ' ' '|'`
    alterar_configuration2=`echo $alterar_configuration | sed 's/Servicos|Comuns/Servicos Comuns/g'`
    
    # tratando o build do Servicos Comuns
    alterar_configuration3=`echo $alterar_configuration | sed 's/Servicos|Comuns//g'`
    alterar_configuration4=`echo $alterar_configuration3 | tr ' ' '|'`
    alterar_configuration5=`echo $alterar_configuration3 | sed 's/||/|/g'`
    
    multiple_group_build=`echo $multiple_group | sed 's/Servicos Comuns/Servicos_Comuns/g'`
    DATE_TIME=`date +"%Y%m%d_%H%M%S"`

}


criar_paths() {

    # Cria os diretórios de TU e TS
    mkdir -p $pathBranch
    mkdir -p $pathAbsolutoMerge
    mkdir -p $dirBuild
    mkdir -p $dirBuildPincado

}

gerar_pacote() {

    echo "#################################################"
    echo "Gerar o pacote dos itens selecionados"
    echo "#################################################"
    sleep 3

    cd $dir  
    sed -i s'/Servicos_Comuns/Servicos Comuns/'g $listaArtefatos

    rm -rf $package_dir
    mkdir -p $package_dir

    for object in $(echo $multiple_group_build); do
        
        if [ $object = "Servicos_Comuns" ]; then

            cp -rf ${dirBuildPincado}/Servicos\ Comuns $dirBuild
            
            Trata_Servicos_Comuns=`echo "${alterar_configuration5}|Servicos Comuns"`
            Trata_Servicos_Comuns2=`echo $Trata_Servicos_Comuns | sed 's/||/|/g'`
            Trata_Servicos_Comuns3=`echo $Trata_Servicos_Comuns2 | sed 's/=|/=/g'`

        else

            cp -rf ${dirBuildPincado}/${object} $dirBuild

        fi
        
    done

    rm -rf $dirBuild/Servicos_Comuns

    # TRATAR ARQUIVO SETTINGFILE

    cp $settingsFile12c/settingsFile.xml $dirBuild
    sed -i s"&dirbuild&${dirBuild}&"g $dirBuild/settingsFile.xml
    sed -i s"&dirWorkspace&${dirWorkspace}&"g $dirBuild/settingsFile.xml

}

gerar_build() {

    echo "#################################################"
    echo "Gerando Build"
    echo "#################################################"
    
    sh BuildScripts/build12c.sh $dirBuild $settingsFile12c
            
    status=$?
    if [ $status != 0 ];then
        echo "Há erros de compilação na build, verifique o log apresentado acima!"
        exit 3
    fi

    cp -rf ${dirWorkspace}/sbconfig.jar $package_dir
    rm  ${dirWorkspace}/sbconfig.jar 

    rm -rf $dirBuild
    rm -rf $dirBuildPincado

}

############################# MAIN #############################

variaveis
criar_paths
gerar_pacote
gerar_build