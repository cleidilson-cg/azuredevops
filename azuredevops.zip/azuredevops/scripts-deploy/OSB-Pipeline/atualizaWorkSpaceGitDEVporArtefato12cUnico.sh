#!/bin/bash

set -x

#Proxy malandro
export http_proxy="http://bredt1-svprxp03.cgmp-osa.com.br:3128"
export https_proxy="https://bredt1-svprxp03.cgmp-osa.com.br:3128"

package_dir=$1
listaArtefatos=$2
branch=$3
gitProject=$4
application=$5
ambiente="ts"

dir=$(pwd)
dir_projeto="/app/jenkins/workspace/"
projeto="${JOB_NAME}"
settingsFile12c="${dir_projeto}/settingsfile12c"
dirWorkspace="${dir_projeto}/${projeto}"
dirBuildPincado="${dirWorkspace}/buildPincado"
dirBuild="${dirWorkspace}/build"
pathBranch="${dirWorkspace}/DEV"
pathBranchOsb="$pathBranch/$gitProject/$application"
pathAbsolutoMerge="${dirWorkspace}/DEV1"
pathAbsolutoMergeOsb="$pathAbsolutoMerge/$gitProject/$application"
artefatos=$(ls $listaArtefatos | cut -f6 -d"/")
resultListaArtefatos=$(cat $listaArtefatos)
multiple_group=$(cat $listaArtefatos | cut -f2 -d"/" | sort | uniq)
alterar_configuration=$(echo $multiple_group | tr ' ' '|')
alterar_configuration2=$(echo $alterar_configuration | sed 's/Servicos|Comuns/Servicos Comuns/g')
# tratando o build do Servicos Comuns
alterar_configuration3=$(echo $alterar_configuration | sed 's/Servicos|Comuns//g')
alterar_configuration4=$(echo $alterar_configuration3 | tr ' ' '|')
alterar_configuration5=$(echo $alterar_configuration3 | sed 's/||/|/g')
dia=$(date +"%d")
mes=$(date +"%m")
ano=$(date +"%Y")
################################################################

multiple_group_build=$(echo $multiple_group | sed 's/Servicos Comuns/Servicos_Comuns/g')
DATE_TIME=$(date +"%Y%m%d_%H%M%S")

#verifica se o arquivo de merge foi criado
#ls $listaArtefatos

status=$?
if [ $status != 0 ]; then
    echo ""
    echo "Não existe arquivo de BUILD em $listaArtefatos"
    echo''
    exit 3
fi

# Cria os diretórios de TU e TS
mkdir -p $pathBranch
mkdir -p $pathAbsolutoMerge
mkdir -p $dirBuild
mkdir -p $dirBuildPincado

# Verifica se os diretórios existem, caso existam, serão apagado e clonando novamente
echo "Clonando $branch..."
echo " "
if [ -d "$pathBranch" ]; then
    cd $pathBranch
    rm -rf $gitProject
    git clone -b $branch ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/$gitProject --depth=1
fi
echo ""
echo "Clonando tu12c..."
echo ""
if [ -d "$pathAbsolutoMerge" ]; then
    cd $pathAbsolutoMerge
    rm -rf $gitProject
    git clone -b tu12c ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/$gitProject --depth=1
fi
echo ""
echo ""

echo "################ CONTEUDO BRANCH ORIGEM ###############"
cat $pathBranch/osb/BssFullOsbProjects/StpModel/Interface/wsdl/Tarifas/SalvaTarifaEstacionamentoContract.wsdl

cd $pathBranch

#Necessário para que não atrapalhe o for
sed -i s'/Servicos Comuns/Servicos_Comuns/'g $listaArtefatos

if [ $ambiente = "ts" ]; then
    for copiaArtefato in $(cat "$listaArtefatos"); do
        sed -i s'/Servicos Comuns/Servicos_Comuns/'g $listaArtefatos
        #Remove o arquivo solicitado
        #O arquivo de artefatos deverá seguir o exemplo abaixo
        #/IntegracaoCPQD/Fachada/ConsultaRamoAtividade/Xquery/ConsultaRamoAtividadeFachada_obterRamoAtividade_response.xq(excluir)
        if [ $(echo $copiaArtefato | grep "(excluir)") ]; then
            mv -f $pathBranchOsb/Servicos\ Comuns $pathBranchOsb/Servicos_Comuns
            echo "REMOVENDO ARTEFATO $pathBranchOsb$copiaArtefato"
            echo ""
            copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1)
            remover=$(echo "$pathBranchOsb$copiaArtefato_tratado")
            rm -f $pathBranchOsb$copiaArtefato_tratado

            status=$?
            if [ $status != 0 ]; then
                echo "ERRO AO REMOVER ARTEFATO, NAO EXISTE EM TU OU NOME ERRADO"
                exit 3
            fi

            mv -f $pathBranchOsb/Servicos_Comuns $pathBranchOsb/Servicos\ Comuns
            #Verifica se o arquivo é novo, caso seja, ele tentará criar o diretório do arquivo (se dir não existir)
            #O arquivo de artefatos deverá seguir o exemplo abaixo
            #ex: /IntegracaoCPQD/Fachada/SalvaVendaClienteTESTE/SalvaVendaClienteFachadaPS.proxy(novo)
        elif [ $(echo $copiaArtefato | grep "(novo)") ]; then
            echo "ADICIONANDO ARTEFATO NOVO $pathBranchOsb$copiaArtefato"
            echo ""
            # mv -f $pathBranchOsb/Servicos\ Comuns $pathBranchOsb/Servicos_Comuns
            # mv -f $pathAbsolutoMergeOsb/Servicos\ Comuns $pathAbsolutoMergeOsb/Servicos_Comuns
            copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1 | rev | cut -d/ -f1 --complement | rev)
            mkdir -p $pathBranchOsb$copiaArtefato_tratado
            mkdir -p $dirBuildPincado$copiaArtefato_tratado

            copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1)
            copiaArtefato="$copiaArtefato_tratado"
            cp -r "$pathAbsolutoMergeOsb$copiaArtefato_tratado" "$pathBranchOsb$copiaArtefato_tratado"

            status=$?

            if [ $status != 0 ]; then
                echo "ERRO AO ADICIONAR ARTEFATO, NAO EXISTE EM TU OU NOME ERRADO"
                exit 3
            fi

            cp -r "$pathBranchOsb$copiaArtefato_tratado" "$dirBuildPincado$copiaArtefato_tratado"
            # mv -f $pathBranchOsb/Servicos_Comuns $pathBranchOsb/Servicos\ Comuns
            # mv -f $pathAbsolutoMergeOsb/Servicos_Comuns $pathAbsolutoMergeOsb/Servicos\ Comuns

        else

            #Altera o Servicos Comuns para o cp interpretar o espaço em branco
            copiaArtefato_tratado=$(echo $copiaArtefato | sed 's/Servicos_Comuns/Servicos\\ Comuns/g')
            echo "ATUALIZANDO ARTEFATO $pathBranchOsb$copiaArtefato_tratado"

            cp -r "$pathAbsolutoMergeOsb$copiaArtefato_tratado" "$pathBranchOsb$copiaArtefato_tratado"

            status=$?
            if [ $status != 0 ]; then
                echo "ERRO AO ATUALIZAR ARTEFATO, NAO EXISTE EM TU OU NOME ERRADO"
                exit 3
            fi

            copiaArtefato_tratado_path=$(echo $copiaArtefato | rev | cut -d/ -f1 --complement | rev)

            mkdir -p $dirBuildPincado$copiaArtefato_tratado_path

            cp -r "$pathBranchOsb$copiaArtefato_tratado" "$dirBuildPincado$copiaArtefato"
        fi
        rm -rf $pathBranchOsb/Servicos_Comuns
    done

    if [[ -d $dirBuildPincado/Servicos_Comuns ]]; then

        mv -f $dirBuildPincado/Servicos_Comuns $dirBuildPincado/Servicos\ Comuns
    fi

fi
cd $dir
sed -i s'/Servicos_Comuns/Servicos Comuns/'g $listaArtefatos

echo "#################################################"
echo "Gerar o pacote dos itens selecionados"
echo "#################################################"
sleep 3

rm -rf $package_dir
mkdir -p $package_dir

for object in $(echo $multiple_group_build); do

    if [ $object = "Servicos_Comuns" ]; then

        cp -rf ${dirBuildPincado}/Servicos\ Comuns $dirBuild

        Trata_Servicos_Comuns=$(echo "${alterar_configuration5}|Servicos Comuns")
        Trata_Servicos_Comuns2=$(echo $Trata_Servicos_Comuns | sed 's/||/|/g')
        Trata_Servicos_Comuns3=$(echo $Trata_Servicos_Comuns2 | sed 's/=|/=/g')

    else

        cp -rf ${dirBuildPincado}/${object} $dirBuild

    fi

done
rm -rf $dirBuild/Servicos_Comuns

# TRATAR ARQUIVO SETTINGFILE

cp $settingsFile12c/settingsFile.xml $dirBuild
sed -i s"&dirbuild&${dirBuild}&"g $dirBuild/settingsFile.xml
sed -i s"&dirWorkspace&${dirWorkspace}&"g $dirBuild/settingsFile.xml

echo "conteudo do seetingsfile #########################"
cat $dirBuild/settingsFile.xml

# Gerando a Build

echo "Gerando a Build..."
sh /app/jenkins/workspace/BuildScripts/build12c.sh $dirBuild

echo "DIR BUILD $dirbuild"
ls $dirBuild

status=$?
if [ $status != 0 ]; then
    echo "Há erros de compilação na build, verifique o log apresentado acima!"
    exit 3
fi

cp -rf ${dirWorkspace}/sbconfig.jar $package_dir
rm ${dirWorkspace}/sbconfig.jar

rm -rf $dirBuild
rm -rf $dirBuildPincado
