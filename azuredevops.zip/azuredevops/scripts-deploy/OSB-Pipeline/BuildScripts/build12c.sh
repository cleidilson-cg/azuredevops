#!/bin/bash

#project="/home/oel/repositories/git/build12c/BUS_TS_OFFICIAL_GIT_12C/build"
project=$1
settingsFilePath=$2

mw_home="/app/SOA12C/homeSOA12.2.1.0"
configJar="${mw_home}/osb/tools/configjar"
setEnv="${mw_home}/osb/tools/configjar/setenv.sh"

export MW_HOME="$mw_home"

source $setEnv

cd $configJar

sh $configJar/configjar.sh -settingsfile $settingsFilePath/settingsFile.xml