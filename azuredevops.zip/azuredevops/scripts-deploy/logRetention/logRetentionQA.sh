#!/bin/bash

#Pegar todos os group-name
awsGroupName=`aws logs describe-log-groups --profile QA | grep logGroupName | cut -d'"' -f4`

#Alterar logRetention
for i in $(echo $awsGroupName); do
    aws logs put-retention-policy --log-group-name "$i" --retention-in-days 3 --profile QA
done