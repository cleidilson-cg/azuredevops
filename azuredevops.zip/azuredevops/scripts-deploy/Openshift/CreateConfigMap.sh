#!/bin/bash

project=$1
env=$2
#dir="/home/DTC/svc_tfsservice"

#Criando Configmap
#cd $dir/configmapRepo

#echo "Repo udpate..."
#rm -rf ocp-configmap
#git clone -b master ssh://azuredevops.fleetcor.com.br:22/Fleetcor/TPS/_git/ocp-configmap --depth=1

cd ocp-configmap/$project
status=$?
if [ $status != 0 ];then
    echo "O diretório de configmap não existe para o projeto ${project}!"
    echo "Favor criar o projeto no repositório https://azuredevops.fleetcor.com.br/Fleetcor/TPS/_git/ocp-configmap"
    echo "Dúvidas favor procurar a equipe de arquitetura"
    exit 1
else
    ls ${project}-${env}.properties
    status=$?
    if [ $status != 0 ];then
        echo "O diretório de configmap ${project}-${env}.properties não existe!!"
        exit 1
    else
        echo "Criando ou sobrescrevendo o configmap"
        oc create configmap ${project}-${env}-cm --from-env-file=${project}-${env}.properties
        echo "Configmap criado com sucesso!"
    fi
fi