#!/bin/bash
set -x
if [ $# -ne 3 ]
then
  echo "Uso: "
  echo "  ${0} <projeto> <namespace> <ambiente>"
  exit 1
fi

project=$1
application=$2
ambiente=$3

#Entrando no projeto

oc project ${project}-${ambiente}

status=$?
if [ $status != 0 ];then

   echo "O projeto $project não existe ou ainda não foi criado... "
   exit 1
else

   echo "Entrando no projeto '${project}..."
fi


#Verificar se a aplicacao ja existe

oc get svc ${application}-${ambiente}

status=$?
if [ $status != 0 ];then

   echo "Criando a aplicacao ${application}-${ambiente}"
  
else

   echo "A aplicacao ${application}-${ambiente} ja existe"
   exit 0
fi

 # Criando a aplicacao
   oc new-app --name ${application}-${ambiente} --docker-image=image-registry.openshift-image-registry.svc:5000/${project}-${ambiente}/${application}-${ambiente}

   echo "Configurando Labels do Service MESH"
   oc patch deployment/${application}-${ambiente} -p '{"spec":{"template":{"metadata":{"labels":{"app":"'${application}-${ambiente}'"}}}}}' -n ${project}-${ambiente}
   oc patch deployment/${application}-${ambiente} -p '{"spec":{"template":{"metadata":{"labels":{"version":"v1"}}}}}' -n ${project}-${ambiente}
   oc patch deployment/${application}-${ambiente} -p '{"spec":{"template":{"metadata":{"annotations":{"sidecar.istio.io/inject":"true"}}}}}' -n ${project}-${ambiente}

status=$?
if [ $status != 0 ];then

   echo "A aplicacao $application-${ambiente} não existe ou ainda não foi buildada e enviada para o Image Streams... "
   exit 1
else

   echo "Aplicacao $application-${ambiente} criada com sucesso!!!"
fi

#Expose do servico

oc expose svc ${application}-${ambiente} --hostname=${application}.${ambiente}.ocp.fleetcor.com.br


if [ ${ambiente} != "prd" ]; then
  route_name=$(oc get route -n ${project}-${ambiente} -o json | jq -r '.items[].metadata.name'| awk '{print $1}' )
    for rn in $route_name
    do 
      echo "Transformando Rota em SERVICE MESH"
      oc get route $rn -n ${project}-${ambiente} -o yaml >> $rn.yaml
      rn_sm=$(echo $rn | sed 's/\./-/g')
      hosts=$(oc get route $rn -o json | jq -r '.spec.host' )
      route_service=$(oc get route $rn -o json | jq -r '.spec.to.name')
      path=$(oc get routes $rn -o yaml | awk '/name:/ || /path:/  {if (!seen[$1]++) print $2}' |  uniq | grep -v "^null$" | grep -v router)
      path2=$(echo "$path" | tr -d '{}')
      path3=$(echo $path2 | sed 's/ //g')
      path_final=$(echo $path3 ) 
      path_name=$(echo $path3 | grep -oP "^.*(?=\/)")
      path_path=$(echo $path3 | grep -o '/[^/]*$' )
      port=$(oc get route $rn -o json | jq -r '.spec.port.targetPort' | sed 's+-tcp++g')


cat <<EOF >./$rn-gw.yaml
kind: Gateway
apiVersion: networking.istio.io/v1alpha3
metadata:
  name: $rn_sm-gw
  namespace: ${project}-${ambiente}
spec:
  servers:
    - hosts:
        - $hosts
      port:
        name: http
        number: 80
        protocol: HTTP
  selector:
    istio: ingressgateway
EOF


cat <<EOF >./$rn-vs.yaml
kind: VirtualService
apiVersion: networking.istio.io/v1alpha3
metadata:
  name: $rn_sm-vs
  namespace: ${project}-${ambiente}
spec:
  hosts:
    - $hosts
  gateways:
    - $rn_sm-gw
  http:
    - match:
        - uri:
            prefix: /
      route:
        - destination:
            host: $route_service
            port:
              number: $port
EOF
    for i in $path_name
      do

cat <<EOF >./$rn-vs.yaml
kind: VirtualService
apiVersion: networking.istio.io/v1alpha3
metadata:
  name: $rn_sm-vs
  namespace: ${project}-${ambiente}
spec:
  hosts:
    - $hosts
  gateways:
    - $rn_sm-gw
  http:
    - match:
        - uri:
            prefix: $path_path
      route:
        - destination:
            host: $route_service
            port:
              number: $port
EOF

    done  
      oc apply -f $rn-vs.yaml
      oc apply -f $rn-gw.yaml
      oc delete -f $rn.yaml
  done   
fi


status=$?
if [ $status != 0 ];then

   echo "Erro ao expor a rota ${application}.${ambiente}.ocp.fleetcor.com.br. Verifique o log acima "
   exit 1
else

   echo "Rota ${application}.${ambiente}.ocp.fleetcor.com.br criada com sucesso!!!"
fi

#Criando configmap
#if [ $ambiente != "prd" ];then
oc patch deployment $application-${ambiente} --type=json -p '[{"path":"/spec/template/spec/containers/0/envFrom","op":"add","value":[{"prefix":"","configMapRef":{"name":"'${project}'-'${ambiente}'-cm"}}]}]'
#else
#   echo "O Config Map no ambiente de prod não pode ser criado"
#fi
set +x