#!/bin/bash

if [ $# -ne 2 ]
then
  echo "################ Erro ao setar parametros...################"
  echo "Uso: "
  echo "  ${0} <projeto> <ambiente>"
  exit 1
fi

project=$1
env=$2
frente=`echo $project | cut -d- -f3`
dir="/home/DTC/svc_tfsservice"

#Criando o projeto já com o node selector de homologacao
if [ ${env} != "prd" ]; then
  oc adm new-project ${project}-${env} --display-name="${project}-${env}" --description="Micro servicos para a frente $frente" --node-selector='node-compute-nprd='
  echo "Projeto ${project}-${env} criado!"
  echo "Adicionando Project ao Service MESH"
  oc get smmr default -n istio-system-hml -o json | jq '.spec.members |= . + ["'${project}-${env}'"]' | oc apply -f -

else
  oc adm new-project ${project}-${env} --display-name="${project}-${env}" --description="Micro servicos para a frente $frente" --node-selector='node-compute-prd='
  echo "Projeto ${project}-${env} criado!"
fi

#entrando no projeto criado
oc project ${project}-${env}

#atribuir label ao projeto "para a organizacao"
echo "criando label ..."
if [ ${env} != "prd" ]; then
  oc patch namespace ${project}-${env} -p '{"metadata":{"labels":{"env":"no-prd"}}}'

  echo "Adicionando Project ao Service MESH"
  oc get smmr default -n istio-system-hml -o json | jq '.spec.members |= . + ["'${project}-${env}'"]' | oc apply -f -

else
  oc patch namespace ${project}-${env} -p '{"metadata":{"labels":{"env":"prd"}}}'   
fi

#Aplicar patch do annotation: requester
echo "adicionado requester AzureDevops ..."
oc patch namespace ${project}-${env} -p '{"metadata":{"annotations":{"openshift.io/requester":"AzureDevops"}}}'

#criar a secret para o registry
echo "criando secret para o docker registry ..."
cd $dir
oc create secret generic docker-registry-fleetcor --from-file=.dockerconfigjson=auth.json --type=kubernetes.io/dockerconfigjson -n ${project}-${env}

#linkar a secret
echo "linkando secret ..."
oc secrets link default docker-registry-fleetcor --for=pull -n ${project}-${env}