#!/bin/bash

#### Variaveis de entrada

application=$1
compositeName=$2
env=$3
dir_pacote=$4
mantis=$5
listaArtefatos=$6

root=$(pwd)
usuario="isaelin.ewave"
senha="isaelin.ewave"
jobName="BPEL_DEV_GIT"
pathBranch="/app/jenkins/workspace/$jobName/UAT"
pathBranchSOA="$pathBranch/soa"
pathAbsolutoMerge="/app/jenkins/workspace/$jobName/TS"
pathAbsolutoMergeSOA="$pathAbsolutoMerge/soa"
svnDir=$pathBranchSOA/$application
="/app/jenkins/workspace/$jobName/buildPincado"
version='1.0'

# Cria os diretórios de TU e TS
rm -rf $dirBuildPincado
mkdir -p $pathBranch
mkdir -p $pathAbsolutoMerge
mkdir -p $dirBuildPincado
# Verifica se os diretóios existem, caso existam, serão apagado e clonando novamente
echo "Clonando uat..."
echo " "
if [ -d "$pathBranch" ]; then
    cd $pathBranch
    rm -rf soa
    git clone -b uat ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/soa --depth=1
fi
echo ""
echo "Clonando tu..."
echo ""
if [ -d "$pathAbsolutoMerge" ]; then
    cd $pathAbsolutoMerge
    rm -rf soa
    git clone -b tu ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/soa --depth=1
fi
echo "\033[0m"

# .adf/META-INF/adf-config.xml original, pois a equipe de desenvolvimento sobe o arquivo configurado da máquina local.

cp -rf /app/jenkins/workspace/adf/META-INF/adf-config.xml $svnDir/.adf/META-INF/adf-config.xml
sed -i "s/#job/$jobName/g" $svnDir/.adf/META-INF/adf-config.xml
sed -i 's/#ambiente/UAT/g' $svnDir/.adf/META-INF/adf-config.xml

#Verifica Commons MATA BURRO

cd $pathAbsolutoMergeSOA/StpSoaApplication/Artefatos

grep -r "soap:address location=" * | grep -v urlOSB | grep -v urlSOA | grep -v .svn-base

status=$?

if [ $status = 0 ]; then

    echo""
    echo "Os artefatos listados acima estao fora do padrao #urlOSB #urlSOA"
    echo""
    exit 3

fi

mkdir $dir_pacote

# tratando a variável $compositeName para seja possível gerar mais de um objeto ao mesmo tempo
compositeName_multiple=$(echo ${compositeName} | awk '{gsub(/,/,"\n",$1); print $1}')
echo "Objeto(s) que sera(ao) gerado(s): $compositeName_multiple "

#Configurar essas duas variaveis com o caminho do ant e jdev instalados na conta atual
antDir='/app/soa12c/soa/bin'
jdevDir='/app/soa12c/soa/bin'

# recursão para geração dos objetos
for object in $(echo $compositeName_multiple); do

    # Gera o Common por fora do ant, já que o mesmo é apenas um zip do diretório apps do Objetos Artefatos
    if [ $object = "Common" ]; then

        echo ""
        echo "#####################################################################################"
        echo "#################################  GERANDO COMMONS  #################################"
        echo "#####################################################################################"
        echo ""

        cat /app/jenkins/workspace/$jobName/listaArtefatos
        status=$?

        if [ $status != 0 ]; then

            echo "#############################################################################"
            echo "######## Não existe arquivo com os artefatos para compor o COMMONS ##########"
            echo "#############################################################################"
            exit 3

        fi

        for copiaArtefato in $(cat "/app/jenkins/workspace/$jobName/listaArtefatos"); do

            if [ $(echo $copiaArtefato | grep "(excluir)") ]; then

                copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1)
                echo "REMOVENDO ARTEFATO $copiaArtefato"
                echo ""
                rm -rf $pathBranchSOA/StpSoaApplication/Artefatos$copiaArtefato_tratado

                status=$?
                if [ $status != 0 ]; then
                    echo "ERRO AO REMOVER ARTEFATO, NAO EXISTE OU NOME ERRADO"
                    exit 3
                fi

            elif [ $(echo $copiaArtefato | grep "(novo)") ]; then

                copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1 | rev | cut -d/ -f1 --complement | rev)
                echo "ADICIONANDO ARTEFATO NOVO $copiaArtefato"
                echo ""
                mkdir -p $pathBranchSOA/StpSoaApplication/Artefatos$copiaArtefato_tratado
                copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1)
                cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos$copiaArtefato_tratado" "$pathBranchSOA/StpSoaApplication/Artefatos$copiaArtefato_tratado"

                status=$?
                if [ $status != 0 ]; then
                    echo "ERRO AO ADICIONAR ARTEFATO, NAO EXISTE OU NOME ERRADO"
                    exit 3
                fi

                copiaArtefato_tratado_path=$(echo $copiaArtefato | rev | cut -d/ -f1 --complement | rev)
                mkdir -p $dirBuildPincado$copiaArtefato_tratado_path
                cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos$copiaArtefato_tratado" "$dirBuildPincado$copiaArtefato_tratado"

            else

                echo "ATUALIZANDO ARTEFATO $copiaArtefato"
                echo""
                cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos$copiaArtefato" "$pathBranchSOA/StpSoaApplication/Artefatos$copiaArtefato"

                status=$?
                if [ $status != 0 ]; then
                    echo "ERRO AO ATUALIZAR ARTEFATO, NAO EXISTE EM TU OU NOME ERRADO"
                    exit 3
                fi

                copiaArtefato_tratado_path=$(echo $copiaArtefato | rev | cut -d/ -f1 --complement | rev)
                mkdir -p $dirBuildPincado$copiaArtefato_tratado_path
                cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos$copiaArtefato" "$dirBuildPincado$copiaArtefato"

            fi

        done

        cd $dirBuildPincado

        mkdir apps_tmp
        cp -rf apps apps_tmp/apps

        cd apps_tmp

        find apps -name ".svn" -exec rm -rf {} \;

        #zip -r ../Commons.jar apps
        jar cvf Commons.jar apps

        cp -rf $dirBuildPincado/apps_tmp/Commons.jar $dir_pacote

    else

        ### faz move dos objetos

        rm -rf $svnDir/${object}
        mv -f $pathAbsolutoMergeSOA/$application/${object} $svnDir

        #### gera o pacote
        cd $svnDir
        caminhoComposite=$(echo $svnDir/${object})
        cd $caminhoComposite
        echo $caminhoComposite

        # Copiando o diretório Classes que contém os arquivos xmls de referência para a geração do objeto
        #cp -rf $root/classes $caminhoComposite/SCA-INF
        #Gerando o pacote utilizando o ant e jdeveloper setados acima
        #$antDir/ant -f $jdevDir/ant-sca-compile.xml
        #$antDir/ant -f $jdevDir/ant-sca-package.xml -DcompositeDir=$caminhoComposite -DcompositeName=$object -Drevision=$version

        # Removendo jars antigos referentes
        rm -rf $svnDir/$object/deploy/*.jar

        #Substituindo a variável ${pathAnt} para o path do jdev correto
        caminho="\/app\/soa12c\/soa\/bin"

        sed -i s'/${pathAnt}/'$caminho'/'g $svnDir/$object/pom.xml

        # Alterando a versão da build
        sed -i s'/<version>1.0-SNAPSHOT/<version>1.0/'g $svnDir/$object/pom.xml

        ### Gerando com Maven ###
        mvn install

        status=$?
        if [ $status != 0 ]; then
            echo "Há erros de compilação na build, verifique o log apresentado acima!"
            exit 3
        fi

        # copia o pacote para o path passado por parametro
        cd $root
        fullName=sca_$object
        mv $svnDir/$object/deploy/*.jar $dir_pacote/$fullName.jar

        # copia o arquivo configPlan $object_
        cd $caminhoComposite
        copia_configPlan=$(ls *ambstp.xml)
        cp -rfp $svnDir/$object/$copia_configPlan $dir_pacote/$fullName.xml
        # Condição necessária para eliminar lixo gerados quando o objeto não tem configPlan
        if [ -d $dir_pacote/$fullName.xml ]; then
            rm -rf $dir_pacote/$fullName.xml
        fi

    fi

done
