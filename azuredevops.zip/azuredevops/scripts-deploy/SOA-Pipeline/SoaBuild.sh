#!/bin/bash

#### Variaveis de entrada
set -x 

variaveis() {
    #application=$1
    #compositeName=$2    
    #dir_pacote=$4        

    #jobName="$job_name"
    pathBranch="$dir_pacote/$branch_destino-destino"
    pathBranchSOA="$pathBranch/soa"
    pathAbsolutoMerge="$dir_pacote/$branch_origem-origem"
    pathAbsolutoMergeSOA="$pathAbsolutoMerge/soa"
    svnDir=$pathBranchSOA/StpSoaApplication
    dirBuildPincado="$dir_pacote/buildPincado"
    version="1.0"
    #Configurar essas duas variaveis com o caminho do ant e jdev instalados na conta atual
    antDir='/app/soa12c/soa/bin'
    jdevDir='/app/soa12c/soa/bin'
}

create_paths() {
    # Cria os diretórios de TU e TS
    rm -rf $dirBuildPincado
    mkdir -p $pathBranch
    mkdir -p $pathAbsolutoMerge
    mkdir -p $dirBuildPincado
    mkdir -p $pathAbsolutoMergeSOA/StpSoaApplication/Artefatos
    mkdir -p $dir_pacote/Composites
}

git_clone() {
    # Verifica se os diretóios existem, caso existam, serão apagado e clonando novamente
    echo "Clonando $branch_destino ..."
    echo " "
    if [ -d "$pathBranch" ]; then
        cd $pathBranch
        rm -rf soa
        git clone -b $branch_destino ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/soa --depth=1
    fi
    echo ""
    echo "Clonando $branch_origem ..."
    echo ""
    if [ -d "$pathAbsolutoMerge" ]; then
        cd $pathAbsolutoMerge
        rm -rf soa
        git clone -b $branch_origem ssh://tfs.fleetcor.com.br:22/Fleetcor/TPS/_git/soa --depth=1
    fi
    
}

copy_adf_config() {
    # .adf/META-INF/adf-config.xml original, pois a equipe de desenvolvimento sobe o arquivo configurado da máquina local.
    cp -rf $dir_LocalPath/scripts-deploy/SOA-Pipeline/adf/META-INF/adf-config.xml $svnDir/.adf/META-INF/adf-config.xml
    sed -i "s|#job|$dir_pacote|g" $svnDir/.adf/META-INF/adf-config.xml
    sed -i "s|#ambiente|$branch_origem-origem|g" $svnDir/.adf/META-INF/adf-config.xml
}

check_commons() {
    #Verifica Commons MATA BURRO
    cd $pathAbsolutoMergeSOA/StpSoaApplication/Artefatos
    grep -r "soap:address location=" * | grep -v urlOSB | grep -v urlSOA | grep -v .svn-base

    status=$?
    if [ $status = 0 ]; then

        echo""
        echo "Os artefatos listados acima estao fora do padrao #urlOSB #urlSOA"
        echo""
        exit 3

    fi
}

multiple_composites() {
    # tratando a variável $compositeName para seja possível gerar mais de um objeto ao mesmo tempo
    mkdir $dir_pacote

    compositeName_multiple=$(echo ${compositeName} | awk '{gsub(/,/,"\n",$1); print $1}')
    echo "Objeto(s) que sera(ao) gerado(s): $compositeName_multiple "
}

excluir_artefato() {
    copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1)
    echo "REMOVENDO ARTEFATO $copiaArtefato"
    echo ""
    rm -rf $pathBranchSOA/StpSoaApplication/Artefatos/$copiaArtefato_tratado

    status=$?
    if [ $status != 0 ]; then
        echo "ERRO AO REMOVER ARTEFATO, NAO EXISTE OU NOME ERRADO"
        exit 3
    fi
}

novo_artefato() {
    copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1 | rev | cut -d/ -f1 --complement | rev)
    echo "ADICIONANDO ARTEFATO NOVO $copiaArtefato"
    echo ""
    mkdir -p $pathBranchSOA/StpSoaApplication/Artefatos/$copiaArtefato_tratado
    copiaArtefato_tratado=$(echo $copiaArtefato | cut -d'(' -f 1)
    cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos/$copiaArtefato_tratado" "$pathBranchSOA/StpSoaApplication/Artefatos/$copiaArtefato_tratado"

    status=$?
    if [ $status != 0 ]; then
        echo "ERRO AO ADICIONAR ARTEFATO, NAO EXISTE OU NOME ERRADO"
        exit 3
    fi

    copiaArtefato_tratado_path=$(echo $copiaArtefato | rev | cut -d/ -f1 --complement | rev)
    mkdir -p $dirBuildPincado$copiaArtefato_tratado_path
    cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos/$copiaArtefato_tratado" "$dirBuildPincado$copiaArtefato_tratado"

}

atualizar_artefato() {
    echo "ATUALIZANDO ARTEFATO $copiaArtefato"
    echo""
    cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos/$copiaArtefato" "$pathBranchSOA/StpSoaApplication/Artefatos/$copiaArtefato"
    #cp -r "$pathBranchSOA/StpSoaApplication/Artefatos/$copiaArtefato" "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos/$copiaArtefato" 

    status=$?
    if [ $status != 0 ]; then
        echo "ERRO AO ATUALIZAR ARTEFATO, NAO EXISTE EM TU OU NOME ERRADO"
        exit 3
    fi

    copiaArtefato_tratado_path=$(echo $copiaArtefato | rev | cut -d/ -f1 --complement | rev)
    mkdir -p $dirBuildPincado$copiaArtefato_tratado_path
    cp -r "$pathAbsolutoMergeSOA/StpSoaApplication/Artefatos/$copiaArtefato" "$dirBuildPincado$copiaArtefato"
}

pre_build() {
    ### faz move dos objetos
    rm -rf $svnDir/${object}
    mv -f $pathAbsolutoMergeSOA/$application/${object} $svnDir

    #### gera o pacote
    cd $svnDir
    caminhoComposite=$(echo $svnDir/${object})
    cd $caminhoComposite
    echo $caminhoComposite

    # Removendo jars antigos referentes
    rm -rf $svnDir/$object/deploy/*.jar

    #Substituindo a variável ${pathAnt} para o path do jdev correto
    caminho="\/app\/soa12c\/soa\/bin"

    sed -i s'/${pathAnt}/'$caminho'/'g $svnDir/$object/pom.xml

    # Alterando a versão da build
    sed -i s'/<version>1.0-SNAPSHOT/<version>1.0/'g $svnDir/$object/pom.xml
}
buid() {

    ### Gerando com Maven ###
    mvn install

    status=$?
    if [ $status != 0 ]; then
        echo "Há erros de compilação na build, verifique o log apresentado acima!"
        exit 3
    fi
}

pos_build() {
    # copia o pacote para o path passado por parametro
    cd $dir_pacote
    pwd
    ls

    fullName=sca_$object
    mv $svnDir/$object/deploy/*.jar $dir_pacote/$fullName.jar

    # copia o arquivo configPlan $object_
    cd $caminhoComposite
    copia_configPlan=$(ls *ambstp.xml)
    cp -rfp $svnDir/$object/$copia_configPlan $dir_pacote/$fullName.xml

    # Condição necessária para eliminar lixo gerados quando o objeto não tem configPlan
    if [ -d $dir_pacote/$fullName.xml ]; then
        rm -rf $dir_pacote/$fullName.xml
    fi

    
    
}
######################### MAIN ##########################

set -x 

variaveis
create_paths
git_clone
copy_adf_config
check_commons
multiple_composites

# recursão para geração dos objetos
for object in $(echo $compositeName_multiple); do
    # Gera o Common por fora do ant, já que o mesmo é apenas um zip do diretório apps do Objetos Artefatos
    if [ $object = "Common" ]; then
        echo ""
        echo "##########################################"
        echo "############  GERANDO COMMONS  ###########"
        echo "##########################################"
        echo ""

        cat $dir_pacote/listaArtefatos
        status=$?

        if [ $status != 0 ]; then
            echo "########################################################"
            echo "######## NÃO EXISTE ARTEFATOS PARA O COMMONS ###########"
            echo "########################################################"
            exit 3
        fi

        for copiaArtefato in $(cat "$dir_pacote/listaArtefatos"); do
            if [ $(echo $copiaArtefato | grep "(excluir)") ]; then
                excluir_artefato
            elif
                [ $(echo $copiaArtefato | grep "(novo)") ]
            then
                novo_artefato
            else
                atualizar_artefato
            fi
        done

        cd $dirBuildPincado
        mkdir apps_tmp
        cp -rf apps apps_tmp/apps
        cd apps_tmp
        find apps -name ".svn" -exec rm -rf {} \;
        jar cvf Commons.jar apps
        cp -rf $dirBuildPincado/apps_tmp/Commons.jar $dir_pacote
    else
        pre_build
        
        ### Gerando com Maven ###
        mvn install

        status=$?
        if [ $status != 0 ]; then
            echo "Há erros de compilação na build, verifique o log apresentado acima!"
            exit 3
        fi

        pos_build
    fi
done

cp $dir_pacote/*.jar $dir_pacote/Composites

cd $dir_pacote/Composites/
rm -rf apps
zip -v composites.zip *
rm *.jar
