#!/bin/bash


if [ $# -ne 3 ]
then
  echo "Uso: "
  echo "  ${0} <projeto> <namespace> <ambiente>"
  exit 1
fi


project=$1
application=$2
ambiente=$3

#Entrando no projeto

oc project ${project}-${ambiente}

status=$?
if [ $status != 0 ];then

   echo "O projeto $project não existe ou ainda não foi criado... " 
   exit 1
else

   echo "Entrando no projeto '${project}..."
fi


#Verificar se a aplicacao ja existe

oc get svc ${application}-${ambiente}

status=$?
if [ $status != 0 ];then

   echo "Criando a aplicacao ${application}-${ambiente}"
else

   echo "A aplicacao ${application}-${ambiente} ja existe"
   exit 0
fi

# Criando a aplicacao
oc new-app --name ${application}-${ambiente} --docker-image=image-registry.openshift-image-registry.svc:5000/${project}/${application}-${ambiente}

status=$?
if [ $status != 0 ];then

   echo "A aplicacao $application-${ambiente} não existe ou ainda não foi buildada e enviada para o Image Streams... "
   exit 1
else

   echo "Aplicacao $application-${ambiente} criada com sucesso!!!"
fi

#Expose do servico

oc expose svc ${application}-${ambiente} --hostname=${application}.${ambiente}.ocp.fleetcor.com.br

status=$?
if [ $status != 0 ];then

   echo "Erro ao expor a rota ${application}.${ambiente}.ocp.fleetcor.com.br. Verifique o loga acima "
   exit 1
else

   echo "Rota ${application}.${ambiente}.ocp.fleetcor.com.br criada com sucesso!!!"
fi