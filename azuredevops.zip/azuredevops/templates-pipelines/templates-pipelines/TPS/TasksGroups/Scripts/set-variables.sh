export USER=$(USER)
      
export JAVA_HOME=$(JAVA_HOME)
export PATH=$PATH:$JAVA_HOME/bin

export M2_HOME=$(M2_HOME)
export M2=$M2_HOME/bin
export PATH=$M2:$PATH

REPO=$(echo $(Build.Repository.Name) | grep "ms-")
if [ "$(Build.Repository.Name)" != "$REPO" ]; then
    PACK="pack_jsf"
else
    PACK="pack_ms"
fi

export PACK=$PACK
echo "##vso[task.setvariable variable=PACK]$PACK"