## Script para renomear o pacote gerado no build
## Autor da última modificação: Lucas Mucheroni
## Data da última atualização: 10/12/2020

## Renomeando o pacote com a extensão ear
EAR=$(Build.Repository.Name)-ear
if [ -d "$EAR" ]; then
    cd $(Build.Repository.Name)-ear/target/
    PACOTE=$(ls *.ear)
    if [ "$PACOTE" != "$(Build.Repository.Name)-ear.ear" ]; then mv $PACOTE $(Build.Repository.Name)-ear.ear; fi
    PACOTE=$(ls *.ear)
    PATH=$(pwd)

## Renomeando o pacote com a extensão jar
else
    cd target/
    JAR=$(ls *.jar)
    if [ -f "$JAR" ]; then
        PACOTE=$(ls *.jar)
        if [ "$PACOTE" != "$(Build.Repository.Name).jar" ]; then mv $PACOTE $(Build.Repository.Name).jar; fi
        PACOTE=$(ls *.jar)
        PATH=$(pwd)

## Renomeando o pacote com a extensão war
    else
        PACOTE=$(ls *.war)
        if [ "$PACOTE" != "$(Build.Repository.Name).war" ]; then mv $PACOTE $(Build.Repository.Name).war; fi
        PACOTE=$(ls *.war)
        PATH=$(pwd)
    fi
fi

## Variaveis do nome do pacote e o diretório do mesmo para
## ser utilizado em outros steps
export DIR=$PATH
echo "##vso[task.setvariable variable=DIR]$DIR"

export PACKAGE=$PACOTE
echo "##vso[task.setvariable variable=PACKAGE]$PACKAGE"